# Architecture Docker - srv759970

Documentation complète de l'architecture Docker et de la cartographie des dépendances.

---

## 📊 Vue d'Ensemble

L'infrastructure srv759970 utilise Docker pour déployer et gérer ses services. Cette page documente l'architecture, les réseaux, volumes et dépendances entre conteneurs.

---

## 🏗️ Architecture Globale

```mermaid
graph TB
    subgraph "Infrastructure Partagée"
        Redis[redis-shared<br/>Port: 6379]
        Postgres[postgresql-shared<br/>Port: 5432]
        MySQL[mysql-shared<br/>Port: 3306]
    end

    subgraph "Services AI - RAGFlow Cluster"
        RAG_Server[ragflow-server<br/>6.5GB RAM]
        RAG_ES[ragflow-es01<br/>Elasticsearch]
        RAG_Minio[ragflow-minio<br/>Object Storage]
        RAG_MySQL[ragflow-mysql]
        RAG_Etcd[ragflow-etcd]
    end

    subgraph "Services AI - Autres"
        XTTS[xtts-api<br/>2.5GB RAM<br/>Port: 8020]
        Ollama[ollama<br/>Systemd<br/>Port: 11434]
        Whisper[whisper-faster<br/>Port: 8001]
        WhisperX[whisperx<br/>Port: 8002]
        Tika[tika-server<br/>Port: 9998]
    end

    subgraph "Services Documents"
        Paperless[paperless-ngx<br/>1.3GB RAM]
        PL_Redis[paperless-redis]
        PL_Postgres[paperless-postgres]
    end

    subgraph "Services Collaboration"
        Nextcloud[nextcloud<br/>130MB RAM]
        NC_DB[nextcloud-db]
        NC_Redis[nextcloud-redis]
        Jitsi[jitsi<br/>220MB RAM]
    end

    subgraph "Websites WordPress"
        WP_Clem[wordpress-clemence<br/>PHP-FPM]
        WP_Clem_Nginx[nginx-clemence]
        WP_Clem_MySQL[mysql-clemence]

        WP_Solid[wordpress-solidarlink<br/>PHP-FPM]
    end

    subgraph "Infrastructure & Monitoring"
        Portainer[portainer<br/>Port: 9000]
        Dozzle[dozzle<br/>Port: 8888]
        Glances[glances<br/>Port: 61208]
        Dashy[dashy<br/>Port: 4000]
        AutoStart[docker-autostart<br/>Node.js Service]
    end

    subgraph "Applications"
        MemVid[memvid-api<br/>490MB RAM]
        Dashboard[support-dashboard]
        SharePoint[sharepoint-dashboards]
        Cristina[cristina-backend<br/>Strapi]
    end

    %% Dépendances Infrastructure
    RAG_Server --> RAG_ES
    RAG_Server --> RAG_Minio
    RAG_Server --> RAG_MySQL
    RAG_Server --> RAG_Etcd

    Paperless --> PL_Redis
    Paperless --> PL_Postgres

    Nextcloud --> NC_DB
    Nextcloud --> NC_Redis

    WP_Clem --> WP_Clem_MySQL
    WP_Clem_Nginx --> WP_Clem

    %% Services utilisant l'infra partagée
    Cristina -.-> Postgres
    MemVid -.-> Redis

    %% Auto-Start management
    AutoStart -.->|contrôle| RAG_Server
    AutoStart -.->|contrôle| XTTS
    AutoStart -.->|contrôle| Paperless
    AutoStart -.->|contrôle| Nextcloud
    AutoStart -.->|contrôle| Jitsi
    AutoStart -.->|contrôle| WP_Clem
    AutoStart -.->|contrôle| WP_Solid

    style Redis fill:#ff6b6b
    style Postgres fill:#4ecdc4
    style MySQL fill:#ffe66d
    style AutoStart fill:#95e1d3
    style RAG_Server fill:#ff6b6b
    style XTTS fill:#ffa07a
    style Paperless fill:#98d8c8
```

---

## 🌐 Réseaux Docker

### Réseaux Principaux

| Réseau | Conteneurs | Usage |
|--------|-----------|-------|
| **ragflow_default** | 5 | Cluster RAGFlow (server, ES, minio, mysql, etcd) |
| **nextcloud_default** | 3 | Nextcloud + DB + Redis |
| **paperless_default** | 3 | Paperless + PostgreSQL + Redis |
| **wordpress-clemence_default** | 3 | WordPress Clemence (nginx, php-fpm, mysql) |
| **wordpress-solidarlink_default** | 2 | WordPress SolidarLink |
| **monitoring_default** | 3 | Grafana + Prometheus + Loki (arrêtés) |

### Conteneurs Multi-Réseaux

Certains conteneurs sont connectés à plusieurs réseaux pour permettre la communication inter-services :

```mermaid
graph LR
    Container[Container]
    Net1[Network 1]
    Net2[Network 2]
    Net3[Network 3]

    Container --> Net1
    Container --> Net2
    Container --> Net3
```

**Exemples** :
- Services nécessitant accès à l'infra partagée + réseau propre
- Reverse proxies (nginx) connectés à plusieurs backends

---

## 💾 Volumes Docker

### Volumes par Projet

| Projet | Volumes | Statut | Espace |
|--------|---------|--------|--------|
| **ragflow** | 4 volumes | ✅ Actif | ~15GB |
| **nextcloud** | 3 volumes | ⏸️ Auto-stop | ~5GB |
| **paperless-ngx** | 3 volumes | ⏸️ Auto-stop | ~8GB |
| **wordpress-clemence** | 2 volumes | ⏸️ Auto-stop | ~200MB |
| **monitoring** | 3 volumes | 🔴 Arrêté | ~2GB |

### Volumes Orphelins Détectés

⚠️ **18 volumes potentiellement orphelins** de projets supprimés/archivés :

- `invidious_*` - Projet supprimé
- `paperless-ai_*` - Remplacé par paperless-ngx
- `rag-anything_*` - Projet archivé
- `open-webui_*` - Projet supprimé
- `wordpress-jesuishyperphagique_*` - Site supprimé
- `wordpress-panneauxsolidaires_*` - Site supprimé
- `wordpress-shared-db_*` - Remplacé par mysql-clemence

**Action recommandée** : Audit puis suppression pour libérer ~5-10GB

```bash
# Lister les volumes orphelins
docker volume ls | grep -E "invidious|paperless-ai|rag-anything|open-webui"

# Supprimer après confirmation
docker volume prune
```

---

## 📈 Statistiques Actuelles

**Mise à jour** : 2025-10-27

| Métrique | Valeur |
|----------|--------|
| **Conteneurs Total** | 36 |
| 🟢 **Actifs** | 23 |
| 🔴 **Arrêtés** | 13 |
| ⚠️ **Unhealthy** | 2 (human-chain-backend, discord-voice-bot) |
| **Réseaux Customs** | 17 |
| **Volumes Total** | 41 |
| **Volumes Orphelins** | 18 |

---

## 🔍 Services par Catégorie

### Services AI/ML

```mermaid
graph TB
    subgraph "RAGFlow Cluster - 6.5GB"
        A[ragflow-server]
        B[elasticsearch]
        C[minio]
        D[mysql]
        E[etcd]
    end

    subgraph "Autres AI"
        F[XTTS-API - 2.5GB]
        G[Ollama - systemd]
        H[Whisper - 500MB]
        I[WhisperX - 800MB]
        J[Tika - 300MB]
    end

    style A fill:#ff6b6b
    style F fill:#ffa07a
    style G fill:#a8e6cf
    style H fill:#dcedc1
    style I fill:#ffd3b6
    style J fill:#ffaaa5
```

**Consommation RAM** : ~11GB total (pic)

### Services Documents & Collaboration

- **Paperless-ngx** : 1.3GB (auto-stop)
- **Nextcloud** : 130MB (auto-stop)
- **Jitsi** : 220MB (auto-stop)

### Websites

- **WordPress Clemence** : ~150MB (auto-stop)
- **WordPress SolidarLink** : ~120MB (auto-stop)
- **Cristina (Astro)** : Statique via Nginx

---

## 🚨 Conteneurs Problématiques

### Unhealthy (2)

1. **human-chain-backend**
   - Statut : Unhealthy
   - Cause probable : Health check échoue
   - Action : Investigation logs + restart

2. **discord-voice-bot**
   - Statut : Unhealthy
   - Cause probable : Connexion Discord perdue
   - Action : Vérifier token + restart

```bash
# Diagnostiquer
docker logs human-chain-backend --tail 50
docker inspect human-chain-backend | jq '.[0].State.Health'

# Redémarrer
docker restart human-chain-backend
```

---

## 🔄 Gestion Auto-Start/Stop

Services avec auto-stop (économie RAM 66%) :

| Service | RAM Pic | Timeout | Mode |
|---------|---------|---------|------|
| RAGFlow | 6.5GB | 3 min | Dynamic page |
| XTTS-API | 2.5GB | 3 min | Blocking |
| Paperless | 1.3GB | 3 min | Dynamic page |
| Nextcloud | 130MB | 3 min | Dynamic page |
| WordPress Clemence | 150MB | 3 min | Ghost theme |
| WordPress SolidarLink | 120MB | 3 min | Hacker Terminal |

➡️ Voir [Documentation Auto-Stop](../services/automation/docker-autostart.md) pour détails

---

## 🛠️ Maintenance

### Audit Régulier

```bash
# Analyser les dépendances
python scripts/monitoring/analyze-docker-dependencies.py

# Vérifier les volumes orphelins
docker volume ls -qf dangling=true

# Espace disque utilisé
docker system df -v
```

### Nettoyage

```bash
# Nettoyer volumes inutilisés (ATTENTION: destructif)
docker volume prune

# Nettoyer images non utilisées
docker image prune -a

# Nettoyage complet (volumes + images + networks)
docker system prune -a --volumes
```

### Monitoring Proactif

```bash
# Vérifier conteneurs unhealthy
docker ps --filter health=unhealthy

# Top consommateurs RAM
docker stats --no-stream --format "table {{.Name}}\t{{.MemUsage}}" | sort -k2 -hr | head -10

# Vérifier services auto-start
bash scripts/deployment/check-autostart-status.sh
```

---

## 📚 Ressources

- [Script d'analyse](../../scripts/README.md#monitoring-analyze-docker-dependenciespy)
- [Services Status Live](../../SERVICES_STATUS.md)
- [Docker Auto-Start Documentation](../services/automation/docker-autostart.md)
- [Emergency Runbook](../EMERGENCY_RUNBOOK.md)

---

## 🚀 Évolutions Prévues

- [ ] Migration vers Docker Swarm pour haute disponibilité
- [ ] Mise en place de Traefik pour load balancing automatique
- [ ] Intégration Prometheus pour métriques détaillées par conteneur
- [ ] Alerting automatique sur conteneurs unhealthy
- [ ] Backup automatique des volumes critiques

---

**Dernière analyse** : 2025-10-27
**Outil** : `scripts/monitoring/analyze-docker-dependencies.py`
**Mainteneur** : Infrastructure Team
