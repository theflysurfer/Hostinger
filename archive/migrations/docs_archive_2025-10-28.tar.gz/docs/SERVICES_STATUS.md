# 🚀 Services Status - Live

!!! info "Auto-Generated Page"
    Cette page est générée automatiquement toutes les 5 minutes via le script `scripts/generate-services-status.sh`.

**Dernière mise à jour:** 2025-10-23 18:53:47 UTC


## 📊 Statistiques Globales

| Métrique | Valeur |
|----------|--------|
| **Total containers** | 64 |
| **🟢 En cours d'exécution** | 42 |
| **🔴 Arrêtés** | 22 |
| **Serveur** | srv759970.hstgr.cloud |

---


## 📦 Tous les Services

| Container | Status | Uptime | Ports |
|-----------|--------|--------|-------|
| `18183ed6dcdf_rag-anything-api` | 🔴 stopped | - |
| `dashy` | 🟢 18 minutes (healthy) | 0.0.0.0:4000->8080/tcp, [::]:4000->8080/tcp |
| `dozzle` | 🔴 stopped | 0.0.0.0:8888->8080/tcp, [::]:8888->8080/tcp |
| `faster-whisper-worker` | 🟢 3 hours | 8003/tcp |
| `faster-whisper` | 🔴 stopped | 0.0.0.0:8001->8000/tcp, [::]:8001->8000/tcp |
| `glances` | 🟢 3 hours | 127.0.0.1:61208->61208/tcp, 61209/tcp |
| `grafana` | 🟢 3 hours | 0.0.0.0:3001->3000/tcp, [::]:3001->3000/tcp |
| `hbbr` | 🟢 3 hours | 0.0.0.0:21117->21117/tcp, [::]:21117->21117/tcp, 0 |
| `hbbs` | 🔴 stopped | 0.0.0.0:21115-21116->21115-21116/tcp, [::]:21115-2 |
| `impro-manager` | 🟢 8 minutes (unhealthy) | 0.0.0.0:8504->3001/tcp, [::]:8504->3001/tcp |
| `jitsi-jicofo` | 🔴 stopped | - |
| `jitsi-jvb` | 🟢 3 hours | 0.0.0.0:10000->10000/udp, [::]:10000->10000/udp |
| `jitsi-prosody` | 🟢 3 hours | 5222/tcp, 5280/tcp |
| `jitsi-web` | 🔴 stopped | 127.0.0.1:8510->80/tcp, 127.0.0.1:8511->443/tcp |
| `loki` | 🟢 3 hours | 127.0.0.1:3100->3100/tcp |
| `loving_curran` | 🔴 stopped | - |
| `memvid-api` | 🟢 3 hours (healthy) | 0.0.0.0:8506->8503/tcp, [::]:8506->8503/tcp |
| `memvid-ui` | 🟢 3 hours (healthy) | 0.0.0.0:8507->8501/tcp, [::]:8507->8501/tcp |
| `memvid-worker` | 🟢 3 hours (unhealthy) | 8503/tcp |
| `mkdocs` | 🔴 stopped | - |
| `mongodb-exporter` | 🔴 stopped | 127.0.0.1:9216->9216/tcp |
| `mongodb-shared` | 🟢 3 hours | 127.0.0.1:27017->27017/tcp |
| `mysql-clemence` | 🟢 3 hours | 3306/tcp, 33060/tcp |
| `mysql-solidarlink` | 🟢 3 hours | 3306/tcp, 33060/tcp |
| `mysql-wordpress-shared` | 🔴 stopped | 33060/tcp, 0.0.0.0:3307->3306/tcp, [::]:3307->3306 |
| `nextcloud-cron` | 🟢 3 hours | 80/tcp |
| `nextcloud` | 🟢 3 hours (healthy) | 127.0.0.1:8505->80/tcp |
| `nginx-clemence` | 🟢 3 hours | 0.0.0.0:9002->80/tcp, [::]:9002->80/tcp |
| `nginx-jesuishyperphagique` | 🟡 Restarting (1) 10 seconds ago | - |
| `nginx-panneauxsolidaires` | 🟡 Restarting (1) 37 seconds ago | - |
| `nginx-solidarlink` | 🟢 3 hours | 0.0.0.0:9003->80/tcp, [::]:9003->80/tcp |
| `onlyoffice` | 🔴 stopped | 443/tcp, 127.0.0.1:8508->80/tcp |
| `paperless-ai` | 🟢 3 hours (healthy) | 0.0.0.0:3002->3000/tcp, [::]:3002->3000/tcp |
| `paperless-db` | 🟢 3 hours | 0.0.0.0:5433->5432/tcp, [::]:5433->5432/tcp |
| `paperless-gotenberg` | 🟢 3 hours | 3000/tcp |
| `paperless-redis` | 🟢 3 hours | 0.0.0.0:6382->6379/tcp, [::]:6382->6379/tcp |
| `paperless-webserver` | 🟢 3 hours (healthy) | 0.0.0.0:8600->8000/tcp, [::]:8600->8000/tcp |
| `portainer` | 🔴 stopped | - |
| `postgres-exporter` | 🟢 3 hours | 127.0.0.1:9187->9187/tcp |
| `postgresql-shared` | 🟢 3 hours (healthy) | 127.0.0.1:5432->5432/tcp |
| `prometheus` | 🟢 3 hours | 0.0.0.0:9090->9090/tcp, [::]:9090->9090/tcp |
| `promtail` | 🟢 3 hours | - |
| `ragflow-es-01` | 🟢 3 hours (healthy) | 9300/tcp, 0.0.0.0:1220->9200/tcp, [::]:1220->9200/ |
| `ragflow-minio` | 🟢 3 hours (healthy) | 0.0.0.0:9502->9000/tcp, [::]:9502->9000/tcp, 0.0.0 |
| `ragflow-mysql` | 🟢 3 hours (healthy) | 33060/tcp, 0.0.0.0:5456->3306/tcp, [::]:5456->3306 |
| `ragflow-redis` | 🟢 3 hours (healthy) | 0.0.0.0:6381->6379/tcp, [::]:6381->6379/tcp |
| `ragflow-server` | 🔴 stopped | - |
| `redis-exporter` | 🔴 stopped | 127.0.0.1:9121->9121/tcp |
| `redis-shared` | 🟢 3 hours (healthy) | 127.0.0.1:6379->6379/tcp |
| `rocketchat` | 🔴 stopped | 127.0.0.1:3002->3000/tcp |
| `rq-exporter-faster-whisper` | 🟢 3 hours | 0.0.0.0:9727->9726/tcp, [::]:9727->9726/tcp |
| `rq-exporter-whisperx` | 🟢 3 hours | 0.0.0.0:9726->9726/tcp, [::]:9726->9726/tcp |
| `rq-queue-redis` | 🟢 24 minutes (healthy) | 0.0.0.0:6380->6379/tcp, [::]:6380->6379/tcp |
| `swagger-ui` | 🔴 stopped | 80/tcp, 0.0.0.0:8503->8080/tcp, [::]:8503->8080/tc |
| `tika-server` | 🔴 stopped | - |
| `whisperx-dashboard` | 🟢 24 minutes | 0.0.0.0:9181->9181/tcp, [::]:9181->9181/tcp |
| `whisperx-worker` | 🟢 24 minutes | 8002/tcp |
| `whisperx` | 🟢 24 minutes (healthy) | 0.0.0.0:8002->8002/tcp, [::]:8002->8002/tcp |
| `wordpress-clemence` | 🟢 3 hours | 9000/tcp |
| `wordpress-solidarlink` | 🟢 3 hours | 9000/tcp |
| `wp-cli-clemence` | 🔴 stopped | - |
| `wp-cli-solidarlink` | 🔴 stopped | - |
| `xtts-api` | 🟢 3 hours (healthy) | 0.0.0.0:8004->8004/tcp, [::]:8004->8004/tcp |
| `xtts-streamlit` | 🔴 stopped | 0.0.0.0:8501->8501/tcp, [::]:8501->8501/tcp |

---

## 💻 Ressources Système


| Ressource | Utilisation | Total |
|-----------|-------------|-------|
| **RAM** | 12Gi (81.1%) | 15Gi |
| **Disque** | 138G (72%) | 193G |


### 🔥 Top 10 Consommateurs (RAM)

```
NAME                         MEM USAGE / LIMIT     CPU %
paperless-ai                 1.033GiB / 15.62GiB   0.36%
paperless-webserver          536.8MiB / 15.62GiB   0.08%
paperless-redis              5.449MiB / 15.62GiB   0.31%
paperless-gotenberg          7.035MiB / 15.62GiB   0.05%
paperless-db                 27.47MiB / 15.62GiB   0.00%
impro-manager                49.7MiB / 15.62GiB    0.00%
nginx-clemence               4.941MiB / 15.62GiB   0.00%
wordpress-clemence           69.48MiB / 15.62GiB   0.01%
mysql-clemence               383.6MiB / 15.62GiB   0.74%
glances                      53.71MiB / 256MiB     0.31%
```

---

## 📖 Légende

- 🟢 **Running** - Container actif
- 🔴 **Stopped** - Container arrêté
- 🟡 **Restarting** - Container en redémarrage
- ⚪ **Other** - Autre statut

## 🔄 Mise à Jour

Pour mettre à jour manuellement:

```bash
cd /root/hostinger
./scripts/generate-services-status.sh
```

## 🔗 Liens Rapides

- [Dashy Portal](https://dashy.srv759970.hstgr.cloud) - Dashboard visuel
- [Portainer](http://69.62.108.82:9000) - Gestion Docker
- [Dozzle](https://dozzle.srv759970.hstgr.cloud) - Logs temps réel
- [Grafana](https://monitoring.srv759970.hstgr.cloud) - Monitoring


*Généré le 2025-10-23 18:53:47 UTC*
