# 📊 État du Serveur en Temps Réel

> ⚠️ **Note** : Cette page est générée automatiquement par un script. Dernière mise à jour visible ci-dessous.

---

## Conteneurs Docker

### Statistiques Globales

- **Total conteneurs** : Chargement...
- **Running** : Chargement...
- **Stopped** : Chargement...

### Liste Complète

| Nom | Statut | Depuis | Image |
|-----|--------|--------|-------|
| Chargement... | ... | ... | ... |

---

## Utilisation Ressources

### RAM

- **Total** : Chargement...
- **Utilisé** : Chargement...
- **Libre** : Chargement...

### Disque

- **Total** : Chargement...
- **Utilisé** : Chargement...
- **Libre** : Chargement...

---

## Services avec Auto-Start/Stop

Ces services démarrent automatiquement à la demande et s'arrêtent après 30 minutes d'inactivité :

- Dashy Portal
- MkDocs Documentation
- Nextcloud
- WhisperX (+ workers + redis)
- Faster-Whisper
- Tika
- MemVid (UI + worker)
- RAGFlow (+ ES + MySQL + Redis + MinIO)
- RAG-Anything
- ONLYOFFICE
- Rocket.Chat
- Jitsi Meet

---

*Pour générer cette page automatiquement, utilisez le script `/opt/scripts/generate-server-status.sh`*
