# 🎯 Plan d'Action Master 2025 - srv759970
**Infrastructure de Transcription/RAG & Stack Collaboration**

---

## 📊 État des lieux - Octobre 2025

### Serveur
- **VPS** : Hostinger srv759970.hstgr.cloud (69.62.108.82)
- **Ressources** : 16 GB RAM, 4 vCPU, 193GB stockage
- **Uptime** : 206+ jours ✅
- **Sécurisation** : ✅ COMPLÈTE (UFW, Fail2ban, Basic Auth, backups)
- **Auto-start/stop** : ✅ 22 services configurés (optimisation RAM)

### Services opérationnels

#### 🎙️ Transcription & RAG (Opérationnels)
```
✅ WhisperX (8002)              - 40 MB    - Transcription + diarization
✅ Faster-Whisper (8001)        - 438 MB   - Transcription rapide CPU
✅ Faster-Whisper Queue (8003)  - 45 MB    - API queue RQ
✅ MemVid (8506)                - 469 MB   - Encodage vidéo QR + search sémantique
✅ MemVid UI (8507)             - 44 MB    - Interface Streamlit
✅ RAG-Anything (9510)          - 212 MB   - Pipeline RAG universel
✅ Tika Server (9998)           - 0 MB     - OCR/parsing (auto-start)
✅ Redis RQ (6380)              - 5 MB     - Queue jobs transcription (dédié)
```

#### 📊 Monitoring (Opérationnels)
```
✅ Grafana (3001)               - 112 MB   - Dashboards
✅ Prometheus (9090)            - 40 MB    - Métriques
✅ Loki + Promtail              - 152 MB   - Logs centralisés
✅ RQ Exporters (9726, 9727)    - 48 MB    - Métriques queues
✅ Netdata (19999)              - 362 MB   - Monitoring système
✅ Dozzle (8888)                - 27 MB    - Logs Docker temps réel
✅ Dashy (4000)                 - 105 MB   - Dashboard services
```

#### 🌐 Sites WordPress (Opérationnels)
```
✅ Clémence (9002)              - MySQL dédié (mysql-clemence)
✅ JeSuisHyperphagique (9005)   - MySQL dédié
✅ PanneauxSolidaires (9004)    - MySQL dédié
✅ SolidarLink (standalone)     - MySQL partagé (mysql-wordpress-shared)
```

**⚠️ Note importante** : Chaque WordPress garde son MySQL dédié pour éviter les problèmes de licensing plugins (certains plugins bloquent des features en détectant une base mutualisée).

#### 🛠️ Utilitaires
```
✅ Portainer (9000)             - 21 MB    - Gestion Docker
✅ RustDesk (hbbs/hbbr)         - 3 MB     - Remote desktop
✅ Swagger UI (8503)            - 4 MB     - Documentation API
✅ MkDocs (8005)                - 46 MB    - Documentation
✅ Docker Auto-Start (10000)    - Node.js  - Auto-start services on-demand
```

#### 📚 Documentation & Infrastructure
- **Dashy** : Landing page avec tous les services
- **MkDocs** : Documentation markdown (dont `SERVER_ENVIRONMENT.md`)
- **Swagger UI** : API documentation centralisée
- **Dozzle** : Logs Docker web viewer

### ✅ Stack Collaboration (Phase 1-2 Complétée - Oct 2025)
```
✅ MongoDB partagé (Replica Set rs0)     - Rocket.Chat, Nextcloud metadata
✅ PostgreSQL partagé (v17)               - Nextcloud, ONLYOFFICE
✅ Redis partagé (cache, distinct RQ)    - Sessions, cache applicatif
✅ Nextcloud + ONLYOFFICE                 - Stockage cloud + co-édition documents
✅ Rocket.Chat + Jitsi Meet               - Chat + Visioconférence
```

### ❌ Services manquants (objectifs futurs)
```
❌ Load Balancer Transcription/RAG unifié
❌ Pipeline transcription/résumé intelligent (OCR local)
```

---

## 🎯 Objectifs stratégiques

### 1. Infrastructure de données centralisée
- **Bases de données mutualisées** : MongoDB + PostgreSQL pour apps modernes (Nextcloud, Rocket.Chat, etc.)
- **Cache distribué** : Redis partagé pour sessions/cache applicatif (séparé du Redis RQ transcription)
- **MySQL WordPress** : ⚠️ GARDER instances dédiées (problèmes licensing plugins)
- **Stockage** : Filesystem classique `/opt/storage/` (pas MinIO, complexité inutile)

### 2. Stack Collaboration (4 utilisateurs)
- **Bureautique** : Nextcloud + ONLYOFFICE (co-édition documents)
- **Communication** : Rocket.Chat + Jitsi (chat + visio)
- **Calendrier/Contacts** : CalDAV/CardDAV dans Nextcloud

**⚠️ Hors serveur (externe)** :
- Email : Infomaniak Mail Business ou autre (pas self-hosted)
- MS Office : Optionnel si besoin compat clients (licence externe)

### 3. Load Balancer Transcription/RAG unifié
**Problème actuel** : Services isolés (WhisperX, Faster-Whisper, MemVid, Tika, RAG-Anything)
**Solution** : Routeur intelligent unifié qui :
- Détecte type de contenu (audio → transcription, PDF → OCR, texte → RAG)
- Route vers le meilleur service disponible
- Gère priorités, load balancing, fallback automatique

**Services intégrés** :
- **Transcription** : WhisperX (diarization), Faster-Whisper (rapide)
- **OCR/Parsing** : Tika (documents bureautique), PaddleOCR (slides vidéo)
- **RAG** : RAG-Anything, MemVid (vidéo)
- **À venir** : Vision, embeddings, etc.

### 4. Pipeline transcription intelligent réunions
- **Enregistrement** : Jibri (Jitsi) → MP4 dans `/opt/storage/recordings/`
- **Transcription** : Via Load Balancer → WhisperX (diarization)
- **OCR slides** : PaddleOCR local + ImageHash (détection slides uniques)
- **Résumé** : Ollama qwen2.5:7b (via API existante)
- **Notifications** : Rocket.Chat + Notion

**Budget** : 0€/mois (100% local, pas de Claude Vision API)

---

## 📋 Plan d'Action Consolidé

---

## PHASE 1 : Infrastructure de données (Semaine 1-2)

### 1.1 Stack bases de données centralisée

**Objectif** : Déployer MongoDB + PostgreSQL + Redis partagés pour apps modernes

**⚠️ Important** :
- MySQL WordPress reste **inchangé** (instances dédiées)
- Redis RQ (6380) reste **inchangé** (dédié transcription)
- Nouveau Redis (6379) = cache applicatif seulement

#### Déploiement `/opt/databases-shared/docker-compose.yml`

```yaml
version: '3.8'

services:
  # MongoDB - Base NoSQL partagée
  mongodb:
    image: mongo:7
    container_name: mongodb-shared
    restart: unless-stopped
    ports:
      - "27017:27017"
    volumes:
      - mongodb-data:/data/db
      - mongodb-config:/data/configdb
      - ./mongo-init:/docker-entrypoint-initdb.d:ro
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: ${MONGO_ROOT_PASSWORD}
    command: mongod --auth
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.adminCommand('ping')"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - databases

  # PostgreSQL - Base SQL partagée
  postgresql:
    image: postgres:17-alpine
    container_name: postgresql-shared
    restart: unless-stopped
    ports:
      - "5432:5432"
    volumes:
      - postgresql-data:/var/lib/postgresql/data
      - ./postgres-init:/docker-entrypoint-initdb.d:ro
    environment:
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: postgres
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U admin"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - databases

  # Redis - Cache applicatif partagé (NOT for RQ queues)
  redis-shared:
    image: redis:7-alpine
    container_name: redis-shared
    restart: unless-stopped
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    command: >
      redis-server
      --requirepass ${REDIS_PASSWORD}
      --maxmemory 512mb
      --maxmemory-policy allkeys-lru
      --save ""
      --appendonly no
    # Cache volatil (pas de persistence, LRU eviction)
    healthcheck:
      test: ["CMD", "redis-cli", "--no-auth-warning", "-a", "${REDIS_PASSWORD}", "ping"]
      interval: 5s
      timeout: 3s
      retries: 5
    networks:
      - databases

volumes:
  mongodb-data:
  mongodb-config:
  postgresql-data:
  redis-data:

networks:
  databases:
    driver: bridge
```

#### Différence Redis RQ vs Redis Cache

**⚠️ Pourquoi 2 Redis distincts ?**

| Aspect | `rq-queue-redis` (6380) | `redis-shared` (6379) |
|--------|-------------------------|------------------------|
| **Usage** | Queue jobs transcription | Cache applicatif + sessions |
| **Persistence** | ✅ AOF enabled (critical) | ❌ Volatile (non critical) |
| **Eviction** | ❌ Disabled (never lose jobs) | ✅ LRU (auto-cleanup cache) |
| **Utilisé par** | WhisperX, Faster-Whisper workers | Nextcloud, Rocket.Chat |
| **Criticité** | 🔴 Haute (perte job = perte travail) | 🟡 Moyenne (perte cache = rebuild) |

**Séparation = Best practice** : Queue et cache ont besoins opposés, ne pas mélanger.

#### Scripts d'initialisation

**`mongo-init/01-create-databases.js`**
```javascript
// Rocket.Chat
db = db.getSiblingDB('rocketchat');
db.createUser({
  user: 'rocketchat',
  pwd: 'CHANGE_ME_ROCKETCHAT_PASSWORD',
  roles: [{ role: 'readWrite', db: 'rocketchat' }]
});

// MemVid metadata (optionnel)
db = db.getSiblingDB('memvid');
db.createUser({
  user: 'memvid',
  pwd: 'CHANGE_ME_MEMVID_PASSWORD',
  roles: [{ role: 'readWrite', db: 'memvid' }]
});
```

**`postgres-init/01-create-databases.sql`**
```sql
-- Nextcloud
CREATE DATABASE nextcloud;
CREATE USER nextcloud WITH PASSWORD 'CHANGE_ME_NEXTCLOUD_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE nextcloud TO nextcloud;
\c nextcloud
GRANT ALL ON SCHEMA public TO nextcloud;

-- Transcription pipeline metadata
CREATE DATABASE transcriptions;
CREATE USER transcribe WITH PASSWORD 'CHANGE_ME_TRANSCRIBE_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE transcriptions TO transcribe;
\c transcriptions
GRANT ALL ON SCHEMA public TO transcribe;

-- RAG metadata
CREATE DATABASE rag_metadata;
CREATE USER rag_user WITH PASSWORD 'CHANGE_ME_RAG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE rag_metadata TO rag_user;
\c rag_metadata
GRANT ALL ON SCHEMA public TO rag_user;
```

#### Déploiement

```bash
# 1. Créer structure
ssh root@69.62.108.82 "mkdir -p /opt/databases-shared/{mongo-init,postgres-init}"

# 2. Créer .env avec mots de passe forts
cat > .env <<'ENV'
MONGO_ROOT_PASSWORD=$(openssl rand -base64 32)
POSTGRES_PASSWORD=$(openssl rand -base64 32)
REDIS_PASSWORD=$(openssl rand -base64 32)
ENV

# 3. Créer scripts init
# [Copier contenu mongo-init et postgres-init ci-dessus]

# 4. Transférer configs
scp docker-compose.yml root@69.62.108.82:/opt/databases-shared/
scp -r mongo-init postgres-init root@69.62.108.82:/opt/databases-shared/
scp .env root@69.62.108.82:/opt/databases-shared/

# 5. Démarrer stack
ssh root@69.62.108.82 "cd /opt/databases-shared && docker-compose up -d"

# 6. Vérifier santé
ssh root@69.62.108.82 "docker ps | grep -E 'mongo|postgres|redis-shared'"
ssh root@69.62.108.82 "docker logs mongodb-shared --tail 20"
ssh root@69.62.108.82 "docker logs postgresql-shared --tail 20"
```

**Durée estimée** : 3-4 heures
**Tests de validation** :
- [ ] MongoDB : `docker exec -it mongodb-shared mongosh -u admin -p PASSWORD`
- [ ] PostgreSQL : `docker exec -it postgresql-shared psql -U admin -c "\l"`
- [ ] Redis : `docker exec -it redis-shared redis-cli -a PASSWORD ping`
- [ ] Healthchecks : `docker ps` → 3 services `healthy`

---

### 1.2 Monitoring bases de données

**Ajouter à `/opt/monitoring/docker-compose.yml`** :

```yaml
  # MongoDB Exporter
  mongodb-exporter:
    image: percona/mongodb_exporter:latest
    container_name: mongodb-exporter
    restart: unless-stopped
    ports:
      - "9216:9216"
    environment:
      - MONGODB_URI=mongodb://admin:${MONGO_ROOT_PASSWORD}@mongodb-shared:27017
    networks:
      - monitoring
      - databases-shared_databases

  # PostgreSQL Exporter
  postgres-exporter:
    image: prometheuscommunity/postgres-exporter:latest
    container_name: postgres-exporter
    restart: unless-stopped
    ports:
      - "9187:9187"
    environment:
      - DATA_SOURCE_NAME=postgresql://admin:${POSTGRES_PASSWORD}@postgresql-shared:5432/postgres?sslmode=disable
    networks:
      - monitoring
      - databases-shared_databases

  # Redis Cache Exporter
  redis-cache-exporter:
    image: oliver006/redis_exporter:latest
    container_name: redis-cache-exporter
    restart: unless-stopped
    ports:
      - "9121:9121"
    environment:
      - REDIS_ADDR=redis-shared:6379
      - REDIS_PASSWORD=${REDIS_PASSWORD}
    networks:
      - monitoring
      - databases-shared_databases

networks:
  databases-shared_databases:
    external: true
```

**Mettre à jour `/opt/monitoring/prometheus/prometheus.yml`** :

```yaml
  - job_name: 'mongodb'
    static_configs:
      - targets: ['mongodb-exporter:9216']

  - job_name: 'postgresql'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis-cache'
    static_configs:
      - targets: ['redis-cache-exporter:9121']
```

**Redémarrer monitoring** :
```bash
ssh root@69.62.108.82 "cd /opt/monitoring && docker-compose up -d"
```

**Durée estimée** : 1 heure
**Test** : Grafana → Explore → Métriques MongoDB/PostgreSQL/Redis visibles

---

## PHASE 2 : Stack Collaboration (Semaine 2-4)

### 2.1 Nextcloud + ONLYOFFICE

**Décision** : Auto-hébergé sur srv759970

**`/opt/nextcloud/docker-compose.yml`**

```yaml
version: '3.8'

services:
  nextcloud:
    image: nextcloud:latest
    container_name: nextcloud
    restart: unless-stopped
    ports:
      - "8505:80"
    volumes:
      - nextcloud-data:/var/www/html
      - nextcloud-apps:/var/www/html/custom_apps
      - nextcloud-config:/var/www/html/config
    environment:
      POSTGRES_HOST: postgresql-shared
      POSTGRES_DB: nextcloud
      POSTGRES_USER: nextcloud
      POSTGRES_PASSWORD: ${NEXTCLOUD_DB_PASSWORD}
      NEXTCLOUD_ADMIN_USER: admin
      NEXTCLOUD_ADMIN_PASSWORD: ${NEXTCLOUD_ADMIN_PASSWORD}
      NEXTCLOUD_TRUSTED_DOMAINS: nextcloud.srv759970.hstgr.cloud
      REDIS_HOST: redis-shared
      REDIS_HOST_PASSWORD: ${REDIS_PASSWORD}
      OVERWRITEPROTOCOL: https
    depends_on:
      - onlyoffice
    networks:
      - nextcloud
      - databases-shared_databases
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:80/status.php"]
      interval: 30s
      timeout: 10s
      retries: 3

  onlyoffice:
    image: onlyoffice/documentserver:latest
    container_name: onlyoffice
    restart: unless-stopped
    ports:
      - "8509:80"
    environment:
      JWT_ENABLED: "true"
      JWT_SECRET: ${ONLYOFFICE_JWT_SECRET}
    volumes:
      - onlyoffice-data:/var/www/onlyoffice/Data
      - onlyoffice-logs:/var/log/onlyoffice
    networks:
      - nextcloud

volumes:
  nextcloud-data:
  nextcloud-apps:
  nextcloud-config:
  onlyoffice-data:
  onlyoffice-logs:

networks:
  nextcloud:
    driver: bridge
  databases-shared_databases:
    external: true
```

**Configuration post-install** :
1. Accéder à https://nextcloud.srv759970.hstgr.cloud
2. Créer compte admin
3. Apps → Installer "ONLYOFFICE"
4. Settings → ONLYOFFICE → Configurer :
   - Document Editing Service address : `http://onlyoffice/`
   - JWT Secret : `${ONLYOFFICE_JWT_SECRET}`
5. Activer apps : Calendar, Contacts

**Nginx** : `/etc/nginx/sites-available/nextcloud`
```nginx
server {
    listen 443 ssl http2;
    server_name nextcloud.srv759970.hstgr.cloud;

    ssl_certificate /etc/letsencrypt/live/nextcloud.srv759970.hstgr.cloud/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/nextcloud.srv759970.hstgr.cloud/privkey.pem;

    client_max_body_size 10G;
    client_body_timeout 300s;

    location / {
        proxy_pass http://localhost:8505;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Durée estimée** : 3-4 heures
**Test** :
- [ ] https://nextcloud.srv759970.hstgr.cloud → Login OK
- [ ] Créer document Word → ONLYOFFICE s'ouvre
- [ ] Co-édition à 2 utilisateurs simultanés fonctionne

---

### 2.2 Rocket.Chat + Jitsi

**`/opt/rocketchat/docker-compose.yml`**

```yaml
version: '3.8'

services:
  rocketchat:
    image: rocket.chat:latest
    container_name: rocketchat
    restart: unless-stopped
    ports:
      - "8507:3000"
    environment:
      MONGO_URL: mongodb://rocketchat:${ROCKETCHAT_DB_PASSWORD}@mongodb-shared:27017/rocketchat?authSource=rocketchat
      MONGO_OPLOG_URL: mongodb://admin:${MONGO_ROOT_PASSWORD}@mongodb-shared:27017/local?authSource=admin
      ROOT_URL: https://chat.srv759970.hstgr.cloud
      PORT: 3000
      DEPLOY_METHOD: docker
      DEPLOY_PLATFORM: docker-official
    networks:
      - rocketchat
      - databases-shared_databases
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/info"]
      interval: 30s
      timeout: 10s
      retries: 3

  jitsi:
    image: jitsi/web:latest
    container_name: jitsi
    restart: unless-stopped
    ports:
      - "8508:80"
    environment:
      PUBLIC_URL: https://meet.srv759970.hstgr.cloud
      ENABLE_RECORDING: 0  # Jibri en Phase 3
    networks:
      - rocketchat

networks:
  rocketchat:
    driver: bridge
  databases-shared_databases:
    external: true
```

**Post-install Rocket.Chat** :
1. Accéder à https://chat.srv759970.hstgr.cloud
2. Créer compte admin
3. Admin → Integrations → Jitsi
   - Enable Jitsi : `ON`
   - Jitsi Domain : `meet.srv759970.hstgr.cloud`
4. Admin → Integrations → New Incoming WebHook
   - Channel : `#transcriptions`
   - Copier webhook URL (pour Phase 4)

**Nginx configs** :

`/etc/nginx/sites-available/rocketchat` :
```nginx
server {
    listen 443 ssl http2;
    server_name chat.srv759970.hstgr.cloud;

    ssl_certificate /etc/letsencrypt/live/chat.srv759970.hstgr.cloud/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chat.srv759970.hstgr.cloud/privkey.pem;

    location / {
        proxy_pass http://localhost:8507;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

`/etc/nginx/sites-available/jitsi` :
```nginx
server {
    listen 443 ssl http2;
    server_name meet.srv759970.hstgr.cloud;

    ssl_certificate /etc/letsencrypt/live/meet.srv759970.hstgr.cloud/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/meet.srv759970.hstgr.cloud/privkey.pem;

    location / {
        proxy_pass http://localhost:8508;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

**Durée estimée** : 2-3 heures
**Test** :
- [ ] https://chat.srv759970.hstgr.cloud → Login OK
- [ ] Créer channel → Démarrer visio → Jitsi s'ouvre
- [ ] Audio/vidéo fonctionne

---

## PHASE 3 : Load Balancer Unifié Transcription/RAG (Semaine 4-5)

### 3.1 Problématique actuelle

**Services isolés** :
- `WhisperX (8002)` : Transcription + diarization
- `Faster-Whisper (8001)` : Transcription rapide
- `Faster-Whisper Queue (8003)` : Wrapper avec RQ
- `MemVid (8506)` : Video encoding + semantic search
- `RAG-Anything (9510)` : RAG pipeline
- `Tika (9998)` : OCR + parsing documents

**Problèmes** :
- Client doit connaître quel service appeler
- Pas de fallback automatique
- Pas de routage intelligent par type de contenu
- Pas de load balancing

### 3.2 Architecture Load Balancer Unifié

```
┌─────────────────────────────────────────────────────────────┐
│          Load Balancer Unifié (8100)                        │
│  - Détection type contenu (audio/video/pdf/image/text)     │
│  - Routage intelligent par capacités                        │
│  - Load balancing + priorités                               │
│  - Fallback automatique                                     │
└────────────────┬────────────────────────────────────────────┘
                 │
    ┌────────────┼────────────┬──────────────┬─────────────┐
    ▼            ▼            ▼              ▼             ▼
┌─────────┐ ┌─────────┐ ┌─────────┐ ┌──────────┐ ┌─────────┐
│WhisperX │ │ Faster  │ │ MemVid  │ │   Tika   │ │  RAG    │
│  8002   │ │  8003   │ │  8506   │ │   9998   │ │  9510   │
│Diariz   │ │Fast STT │ │VideoRAG │ │OCR/Parse │ │Universal│
└─────────┘ └─────────┘ └─────────┘ └──────────┘ └─────────┘
```

### 3.3 Implémentation Load Balancer

**`/opt/transcription-lb/docker-compose.yml`**

```yaml
version: '3.8'

services:
  transcription-lb:
    build: .
    container_name: transcription-lb
    restart: unless-stopped
    ports:
      - "8100:8100"
      - "8101:8101"  # Prometheus metrics
    environment:
      - REDIS_URL=redis://redis-shared:6379
      - REDIS_PASSWORD=${REDIS_PASSWORD}
      - WHISPERX_URL=http://whisperx:8002
      - FASTER_WHISPER_URL=http://faster-whisper-queue-api:8003
      - MEMVID_URL=http://memvid-api:8506
      - RAG_URL=http://rag-anything-api:9510
      - TIKA_URL=http://tika-server:9998
    networks:
      - transcription-lb
      - whisperx_whisperx
      - faster-whisper-queue_faster-whisper-net
      - memvid_default
      - rag-anything_default
      - sablier-network
      - databases-shared_databases
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8100/health"]
      interval: 10s
      timeout: 5s
      retries: 3

networks:
  transcription-lb:
    driver: bridge
  whisperx_whisperx:
    external: true
  faster-whisper-queue_faster-whisper-net:
    external: true
  memvid_default:
    external: true
  rag-anything_default:
    external: true
  sablier-network:
    external: true
  databases-shared_databases:
    external: true
```

**`/opt/transcription-lb/main.py`** (extrait clé)

```python
# Service capabilities - TOUS les services
SERVICES = {
    # TRANSCRIPTION (Speech-to-Text)
    "whisperx": {
        "url": WHISPERX_URL,
        "capabilities": ["transcription", "diarization"],
        "input_types": ["audio", "video"],
        "priority": 1,
        "max_concurrent": 2,
        "avg_duration": 300
    },
    "faster-whisper": {
        "url": FASTER_WHISPER_URL,
        "capabilities": ["transcription"],
        "input_types": ["audio", "video"],
        "priority": 2,
        "max_concurrent": 5,
        "avg_duration": 120
    },

    # RAG & SEMANTIC SEARCH
    "rag-anything": {
        "url": RAG_URL,
        "capabilities": ["rag", "qa", "document_analysis"],
        "input_types": ["text", "pdf", "docx"],
        "priority": 1,
        "max_concurrent": 3,
        "avg_duration": 60
    },
    "memvid": {
        "url": MEMVID_URL,
        "capabilities": ["video_encoding", "semantic_search", "video_rag"],
        "input_types": ["video"],
        "priority": 1,
        "max_concurrent": 3,
        "avg_duration": 600
    },

    # OCR / DOCUMENT PARSING
    "tika": {
        "url": TIKA_URL,
        "capabilities": ["ocr", "document_parsing", "metadata_extraction"],
        "input_types": ["pdf", "docx", "pptx", "xlsx", "image"],
        "priority": 1,
        "max_concurrent": 5,
        "avg_duration": 30
    }
}

@app.post("/process")
async def process_universal(
    file: UploadFile = File(...),
    task: Optional[str] = None,  # "transcription", "ocr", "rag", auto-detect si None
    diarize: bool = False,
    priority: Literal["low", "normal", "high"] = "normal"
):
    """
    Endpoint universel - détecte type et route automatiquement

    Exemples :
    - Upload audio.mp3 → Auto-detect → WhisperX ou Faster-Whisper
    - Upload document.pdf → Auto-detect → Tika (parsing) ou RAG-Anything (QA)
    - Upload video.mp4 + task="transcription" → WhisperX
    - Upload video.mp4 + task="semantic_search" → MemVid
    """

    # Détecter type fichier
    file_ext = file.filename.split('.')[-1].lower()
    content_type = file.content_type

    # Auto-detect task si non spécifié
    if not task:
        if file_ext in ['mp3', 'wav', 'ogg', 'm4a']:
            task = "transcription"
        elif file_ext in ['mp4', 'avi', 'mov']:
            task = "transcription"  # Par défaut, peut être "video_rag"
        elif file_ext in ['pdf', 'docx', 'pptx']:
            task = "document_parsing"
        elif file_ext in ['jpg', 'png', 'jpeg']:
            task = "ocr"
        else:
            raise HTTPException(400, "Cannot auto-detect task, please specify")

    # Mapper task → capabilities
    task_mapping = {
        "transcription": ["transcription"],
        "diarization": ["transcription", "diarization"],
        "ocr": ["ocr"],
        "document_parsing": ["document_parsing"],
        "rag": ["rag"],
        "video_rag": ["video_rag", "semantic_search"]
    }

    required_capabilities = task_mapping.get(task, [task])
    if diarize and "diarization" not in required_capabilities:
        required_capabilities.append("diarization")

    # Sélectionner meilleur service
    service_name = await select_best_service(required_capabilities, priority)

    if not service_name:
        raise HTTPException(503, f"No service available for task: {task}")

    # Router vers service
    # [Implementation similaire à v2.0, voir code complet]

    return result
```

**Endpoints disponibles** :
- `POST /process` : Endpoint universel (auto-detect)
- `POST /transcribe` : Transcription spécifique (rétrocompatibilité)
- `POST /ocr` : OCR spécifique
- `POST /rag` : RAG/QA spécifique
- `GET /health` : Status tous les services
- `GET /metrics` : Prometheus metrics

**Durée estimée** : 8-10 heures
**Tests de validation** :
- [ ] Upload audio → Route vers Faster-Whisper (rapide)
- [ ] Upload audio + diarize=true → Route vers WhisperX
- [ ] Upload PDF → Route vers Tika
- [ ] Upload vidéo + task="video_rag" → Route vers MemVid
- [ ] WhisperX down → Fallback Faster-Whisper (sans diarization)
- [ ] Métriques Prometheus visibles

---

## PHASE 4 : Pipeline Transcription Intelligent (Semaine 5-7)

### 4.1 Architecture complète

```
┌─────────┐     ┌────────────┐     ┌──────────────────┐
│  Jitsi  │────▶│   Jibri    │────▶│  Load Balancer   │
│ Meeting │     │ Recording  │     │     (8100)       │
└─────────┘     └─────┬──────┘     └────────┬─────────┘
                      │                      │
                      ▼                      ▼
              ┌──────────────┐    ┌────────────────────┐
              │  /opt/storage│    │  Transcription     │
              │  /recordings │    │  (WhisperX routed) │
              └──────────────┘    └──────┬─────────────┘
                                          │
                      ┌───────────────────┴──────────────┐
                      ▼                                  ▼
           ┌──────────────────┐              ┌──────────────────┐
           │  PaddleOCR       │              │  pyannote.audio  │
           │  Local slides    │              │  Diarization     │
           │  + ImageHash     │              │  (in WhisperX)   │
           └──────────────────┘              └──────────────────┘
                      │                                  │
                      └──────────────┬───────────────────┘
                                     ▼
                        ┌────────────────────────┐
                        │  Ollama qwen2.5:7b     │
                        │  Résumé + Actions      │
                        └────────┬───────────────┘
                                 │
                    ┌────────────┴────────────┐
                    ▼                         ▼
         ┌──────────────────┐     ┌──────────────────┐
         │  Rocket.Chat     │     │     Notion       │
         │  Notification    │     │   Page résumé    │
         └──────────────────┘     └──────────────────┘
```

### 4.2 PaddleOCR vs Tika : Complémentaires

**Tika** (existant, auto-start) :
- ✅ Documents bureautique (PDF, Word, Excel, PowerPoint)
- ✅ Metadata extraction
- ✅ Format universel
- ❌ OCR moyen (Tesseract old)

**PaddleOCR** (nouveau, pour réunions) :
- ✅ OCR excellent sur slides
- ✅ Détection layout avancée
- ✅ Multi-langues
- ❌ Images seulement

**Architecture** :
```
Upload document bureautique → Load Balancer → Tika
Réunion vidéo (slides)      → Pipeline       → PaddleOCR
```

**Pas de remplacement, mais complémentarité** ✅

### 4.3 Service Pipeline (extrait)

**`/opt/transcription-pipeline/docker-compose.yml`**

```yaml
version: '3.8'

services:
  transcription-api:
    build: .
    container_name: transcription-pipeline
    restart: unless-stopped
    ports:
      - "8510:8000"
    environment:
      TRANSCRIPTION_LB_URL: http://transcription-lb:8100
      OLLAMA_URL: http://host.docker.internal:11434
      STORAGE_PATH: /opt/storage
      POSTGRES_URL: postgresql://transcribe:${TRANSCRIBE_PASSWORD}@postgresql-shared/transcriptions
      REDIS_URL: redis://redis-shared:6379
      ROCKETCHAT_WEBHOOK: ${ROCKETCHAT_WEBHOOK}
      NOTION_API_KEY: ${NOTION_API_KEY}
      HF_TOKEN: ${HF_TOKEN}
    volumes:
      - /opt/storage:/opt/storage
    networks:
      - transcription-pipeline
      - transcription-lb_transcription-lb
      - databases-shared_databases
    depends_on:
      - ocr-worker

  ocr-worker:
    build:
      context: .
      dockerfile: Dockerfile.ocr
    container_name: ocr-worker
    restart: unless-stopped
    environment:
      REDIS_URL: redis://redis-shared:6379
      REDIS_PASSWORD: ${REDIS_PASSWORD}
    volumes:
      - /opt/storage:/opt/storage
    networks:
      - databases-shared_databases
    command: rq worker ocr-queue

networks:
  transcription-pipeline:
  transcription-lb_transcription-lb:
    external: true
  databases-shared_databases:
    external: true
```

**Durée estimée** : 4-5 jours
**Budget** : 0€/mois (100% local)

---

## 📊 Métriques de succès

### Infrastructure
- [ ] MongoDB, PostgreSQL, Redis opérationnels et monitorés
- [ ] RAM usage < 50% (actuellement 31% après retrait NeuTTS ✅)
- [ ] Backups quotidiens automatiques testés

### Stack Collaboration
- [ ] 4 utilisateurs actifs Nextcloud + ONLYOFFICE
- [ ] Co-édition documents fonctionne
- [ ] Visio Jitsi : 0 problème audio/vidéo

### Load Balancer
- [ ] Route correctement selon type contenu
- [ ] Fallback automatique si service down
- [ ] Métriques Prometheus visibles

### Pipeline intelligent
- [ ] Résumé réunion < 30min après fin
- [ ] OCR slides > 90% accuracy
- [ ] Notifications automatiques

---

## 💰 Budget consolidé

**Infrastructure VPS** : 99€/mois (Hostinger 16GB)

**Tout le reste : 0€/mois** ✅
- Nextcloud, ONLYOFFICE, Rocket.Chat, Jitsi : Self-hosted
- PaddleOCR : Local (économie 21,60€/mois vs Claude Vision)
- Transcription, RAG : Self-hosted CPU

**Services externes (hors serveur, optionnels)** :
- Email (Infomaniak, etc.) : ~30€/mois
- MS365 Apps si besoin client : ~18€/mois

**Total serveur : 99€/mois** 🎉

---

## ⏱️ Planning détaillé (7 semaines)

### Semaine 1-2 : Infrastructure données
- Déploiement MongoDB, PostgreSQL, Redis
- Monitoring exporters
- Tests validation

### Semaine 2-4 : Stack Collaboration
- Nextcloud + ONLYOFFICE
- Rocket.Chat + Jitsi
- Configuration utilisateurs

### Semaine 4-5 : Load Balancer Unifié
- Développement routeur universel
- Intégration tous les services (WhisperX, Tika, MemVid, RAG-Anything)
- Tests end-to-end

### Semaine 5-7 : Pipeline Intelligent
- OCR worker PaddleOCR
- Intégration Jibri
- Notifications Rocket.Chat + Notion

**Durée totale** : **7 semaines** (~10h/semaine)

---

## 🚨 Risques et mitigation

### Risque 1 : Dépassement RAM
**Probabilité** : Faible (69% libre actuellement après retrait NeuTTS)
**Impact** : Moyen
**Mitigation** :
- Monitoring alertes RAM > 75%
- Limites Docker `mem_limit`
- Auto-start services non-critiques

### Risque 2 : OCR local insuffisant
**Probabilité** : Faible-Moyenne
**Impact** : Moyen
**Mitigation** :
- Tests corpus réel (10 réunions)
- Fallback Tika si PaddleOCR < 80% accuracy

---

## 🔄 Prochaines étapes immédiates

### Cette semaine
1. ✅ Valider plan
2. ⏸️ Générer mots de passe `.env` bases de données
3. ⏸️ **DÉMARRER Phase 1** : Déploiement MongoDB + PostgreSQL + Redis

### Semaine prochaine
4. ⏸️ Tests validation Phase 1
5. ⏸️ Démarrage Phase 2 : Nextcloud

---

## 📚 Documentation

- **Environnement complet** : `docs/SERVER_ENVIRONMENT.md` ✅
- **Plan d'action** : Ce document
- **Dashboards** : Dashy, MkDocs, Swagger UI, Dozzle

---

## ✅ Validation

**Approuvé par** : _________
**Date** : _________
**Prochaine révision** : Décembre 2025

---

## 📝 Changelog

### Version 3.0 - Octobre 2025
- ✅ **NeuTTS retiré** : Libération 6.66 GB RAM (69% RAM libre)
- ✅ **Load Balancer étendu** : Ajout Tika, RAG-Anything, MemVid (endpoint `/process` universel)
- ✅ **Phases réorganisées** : Stack Collaboration (Phase 2) AVANT Load Balancer (Phase 3)
- ✅ **M365/Infomaniak retirés** : Services externes optionnels, hors plan serveur
- ✅ **PaddleOCR complémentaire** : Ne remplace PAS Tika, usage distinct (slides vidéo vs docs bureautique)
- ✅ **Documentation SERVER_ENVIRONMENT.md** : Guide complet pour LLMs/déploiements

### Version 2.0 - Octobre 2025
- Retrait MinIO, MySQL WordPress dédié, Redis séparé

### Version 1.0 - Octobre 2025
- Plan initial consolidé

---

**Version** : 3.0 Master
**Auteur** : Claude Code + Julien
**Remplace** : Toutes versions précédentes
