# Archives - Services Dépréciés

Ce dossier contient la documentation des services qui ne sont plus actifs sur le serveur srv759970.

---

## Services arrêtés ou retirés

### SharePoint Dashboards
- **Status**: Conteneurs absents/supprimés
- **Raison**: Service non utilisé
- **Emplacement serveur**: `/opt/sharepoint-dashboards/`

### Support Dashboard
- **Status**: Conteneurs absents/supprimés
- **Raison**: Service non utilisé
- **Emplacement serveur**: `/opt/support-dashboard/`

### API Portal
- **Status**: Dossier existe mais pas de conteneurs actifs
- **Raison**: En attente de redéploiement ?
- **Emplacement serveur**: `/opt/api-portal/`
- **Note**: Guide existe dans `guides/tooling/api-portal.md` mais service down

---

## Services en auto-start (peuvent apparaître comme "stopped")

Ces services utilisent docker-autostart et démarrent à la demande. Ils peuvent apparaître comme "Exited" mais sont gérés automatiquement :

- **Ollama** (systemd service, actuellement inactive)
- **Dozzle** (Logs Docker)
- **Dashy** (Dashboard)
- **MkDocs** (Cette documentation)
- **RocketChat**
- **WhisperX** (+ workers + redis)
- **Faster-Whisper**
- **Tika**
- **Jitsi** (web, jicofo)
- **ONLYOFFICE**
- **MemVid** (worker)
- **Redis/MongoDB Exporters**

⚠️ **Important** : Ne pas supprimer ces services ! Ils sont actifs mais en mode auto-start/stop pour économiser les ressources.

---

## Nettoyage recommandé

Si ces services archivés ne sont plus nécessaires :

```bash
ssh root@69.62.108.82

# Vérifier les dossiers
ls -la /opt/ | grep -E 'cristina|sharepoint|support'

# Sauvegarder avant suppression
tar -czf archives_services_$(date +%Y%m%d).tar.gz \
  /opt/cristina-site \
  /opt/cristina-backend \
  /opt/sharepoint-dashboards \
  /opt/support-dashboard

# Supprimer (ATTENTION: irréversible!)
# rm -rf /opt/cristina-site
# rm -rf /opt/cristina-backend
# rm -rf /opt/sharepoint-dashboards
# rm -rf /opt/support-dashboard
```

---

## Restauration

Pour restaurer un service archivé, consulter :
- Les backups dans `/root/backups/` ou `/opt/backups/`
- Les archives git si le projet est versionné
- La documentation de déploiement dans `docs/guides/`
