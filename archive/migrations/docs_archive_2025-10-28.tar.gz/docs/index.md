# Documentation srv759970.hstgr.cloud

Bienvenue sur la documentation technique complète du serveur **srv759970.hstgr.cloud**.

## 🚀 Services Principaux

### Stack Collaboration & Productivité

- **[Nextcloud](services/collaboration/nextcloud.md)** - Stockage cloud et synchronisation de fichiers
- **[Rocket.Chat](services/collaboration/rocketchat.md)** - Messagerie instantanée et collaboration d'équipe
- **[Jitsi Meet](services/collaboration/jitsi.md)** - Visioconférence sécurisée et webinaires
- **[Bases de Données Partagées](services/infrastructure/databases-shared.md)** - MongoDB, PostgreSQL, Redis

### APIs de Transcription & Synthèse Vocale

- **[WhisperX](services/ai/whisperx.md)** - Transcription avancée avec diarization (qui parle quand)
- **[Faster-Whisper Queue](services/ai/faster-whisper-queue.md)** - Transcription async avec gestion de queues RQ
- **[XTTS-v2](services/ai/xtts-v2.md)** - Synthèse vocale et clonage de voix
- **[NeuTTS](services/ai/neutts.md)** - API et UI de synthèse vocale neuronale

### Intelligence Artificielle & RAG

- **[Ollama](services/ai/ollama.md)** - Inférence LLM locale (qwen2.5, mistral, llama)
- **[RAGFlow](guides/services/rag/ragflow-raganything.md)** - Plateforme RAG avec ES, MySQL, Redis, MinIO
- **[RAG-Anything](guides/services/rag/ragflow-raganything.md)** - Pipeline RAG universel multimodal
- **[MemVid](guides/services/rag/videorag-docker.md)** - Recherche sémantique dans vidéos
- **[VideoRAG](guides/services/rag/videorag-docker.md)** - RAG spécialisé pour contenus vidéo

### Gestion Documentaire

- **[Paperless-ngx](services/documents/paperless-ngx.md)** - Système de gestion documentaire intelligent avec OCR
- **[Paperless AI](services/documents/paperless-ai.md)** - Assistant IA pour analyse documentaire
- **[Tika](services/ai/tika.md)** - Parsing de documents (PDF, Office, images OCR)

### Sites Web & Applications

- **[Cristina](services/websites/cristina-site.md)** - Site personnel (Astro SSG + Strapi CMS)
- **[Clémence](services/websites/wordpress-clemence.md)** - Site WordPress
- **[SolidarLink](services/websites/wordpress-solidarlink.md)** - Plateforme de solidarité WordPress
- **[Impro Manager](services/apps/impro-manager.md)** - Application de gestion d'improvisation

### Infrastructure & Outils

- **[Glances](services/infrastructure/glances.md)** - Monitoring système léger (métriques CPU, RAM, disque, Docker)
- **[Dozzle](services/infrastructure/dozzle.md)** - Visualisation logs Docker en temps réel
- **[Portainer](services/infrastructure/portainer.md)** - Interface de gestion Docker complète
- **[Monitoring Stack](services/infrastructure/monitoring.md)** - Prometheus + Grafana + Loki pour métriques et logs
- **[Dashy Portal](services/infrastructure/dashy-portal.md)** - Dashboard centralisé de tous les services

## 🏗️ Infrastructure

- **[Docker](infrastructure/docker.md)** - Gestion des conteneurs et réseaux
- **[Nginx](infrastructure/nginx.md)** - Reverse proxy et configuration SSL
- **[Sécurité](infrastructure/security.md)** - Basic auth, SSL, firewall

## 📚 Guides

- **[Déploiement VPS](guides/getting-started/vps-initial-setup.md)** - Configuration initiale du serveur
- **[Email](guides/infrastructure/email-smtp.md)** - Configuration SMTP et alertes
- **[WordPress](guides/services/wordpress/wordpress-docker.md)** - Déploiement sites WordPress avec Docker

## 📊 Portails & Dashboards

### Collaboration
- **Nextcloud**: [https://nextcloud.srv759970.hstgr.cloud](https://nextcloud.srv759970.hstgr.cloud) - Stockage cloud
- **Rocket.Chat**: [https://chat.srv759970.hstgr.cloud](https://chat.srv759970.hstgr.cloud) - Messagerie
- **Jitsi Meet**: [https://meet.srv759970.hstgr.cloud](https://meet.srv759970.hstgr.cloud) - Visioconférence

### Monitoring & Infrastructure
- **Dashy Dashboard**: [https://dashy.srv759970.hstgr.cloud](https://dashy.srv759970.hstgr.cloud) - Vue d'ensemble services
- **Grafana Monitoring**: [https://monitoring.srv759970.hstgr.cloud](https://monitoring.srv759970.hstgr.cloud) - Métriques & Logs
- **Dozzle**: [https://dozzle.srv759970.hstgr.cloud](https://dozzle.srv759970.hstgr.cloud) - Logs Docker temps réel
- **Glances**: [https://glances.srv759970.hstgr.cloud](https://glances.srv759970.hstgr.cloud) - Monitoring système léger ✅ **Sécurisé**
- **Portainer**: [https://portainer.srv759970.hstgr.cloud](https://portainer.srv759970.hstgr.cloud) - Gestion Docker ✅ **Sécurisé**
- **RQ Dashboard**: [https://whisperx-dashboard.srv759970.hstgr.cloud](https://whisperx-dashboard.srv759970.hstgr.cloud) - Queues Redis

## 🔧 APIs Disponibles

| Service | URL | Documentation | Status |
|---------|-----|---------------|--------|
| **Speech-to-Text** |
| WhisperX | https://whisperx.srv759970.hstgr.cloud | [Swagger](https://whisperx.srv759970.hstgr.cloud/docs) | ✅ |
| Faster-Whisper Queue | https://faster-whisper.srv759970.hstgr.cloud | [Swagger](https://faster-whisper.srv759970.hstgr.cloud/docs) | ✅ |
| Faster-Whisper (direct) | http://srv759970.hstgr.cloud:8001 | [Swagger](http://srv759970.hstgr.cloud:8001/docs) | ✅ |
| **Text-to-Speech** |
| NeuTTS API | https://neutts-api.srv759970.hstgr.cloud | [Swagger](https://neutts-api.srv759970.hstgr.cloud/docs) | ✅ |
| XTTS-v2 | http://srv759970.hstgr.cloud:8020 | API REST | ✅ |
| **AI & RAG** |
| Ollama | http://srv759970.hstgr.cloud:11434 | API REST | ✅ |
| RAGFlow | https://ragflow.srv759970.hstgr.cloud | Web UI | ✅ |
| RAG-Anything | https://rag-anything.srv759970.hstgr.cloud | [Swagger](https://rag-anything.srv759970.hstgr.cloud/docs) | ✅ |
| MemVid | https://memvid.srv759970.hstgr.cloud | [Swagger](https://memvid.srv759970.hstgr.cloud/docs) | ✅ |
| **Document Management** |
| Paperless-ngx | https://paperless.srv759970.hstgr.cloud | [API](https://paperless.srv759970.hstgr.cloud/api/docs/) | ✅ |
| Paperless AI | https://paperless-ai.srv759970.hstgr.cloud | [Swagger](https://paperless-ai.srv759970.hstgr.cloud/docs) | ✅ |
| Tika | http://srv759970.hstgr.cloud:9998 | API REST | ✅ |

## 🏗️ Architecture

### Services de Transcription

```
┌──────────── Redis Partagé (rq-queue-redis:6379) ────────────┐
│                                                               │
│  DB 0: Queue "transcription" (WhisperX)                      │
│  DB 1: Queue "faster-whisper-transcription"                  │
│                                                               │
└───────────────────────────────────────────────────────────────┘
         ↓                                 ↓
   whisperx-worker              faster-whisper-worker
         ↓                                 ↓
   WhisperX API (:8002)         Faster-Whisper Queue API (:8003)
```

### Stack Monitoring

```
Grafana (:3001) → Prometheus (:9090) + Loki (:3100)
                       ↓                    ↓
                  RQ Exporters         Promtail
                       ↓                    ↓
                   Redis Queue         Docker Logs
```

## 🔗 Liens Rapides

- **Dashboards**:
  - [Dashy](https://dashy.srv759970.hstgr.cloud) - Vue d'ensemble des services
  - [Dozzle](https://dozzle.srv759970.hstgr.cloud) - Logs Docker temps réel
  - [Grafana](https://monitoring.srv759970.hstgr.cloud) - Métriques et logs

- **Monitoring**:
  - [Prometheus](http://srv759970.hstgr.cloud:9090) - Métriques time-series
  - [RQ Dashboard](https://whisperx-dashboard.srv759970.hstgr.cloud) - Queues Redis

## 📝 Dernières Mises à Jour

- **2025-10-23**: ✅ Synchronisation Dashy ↔ MkDocs - Documentation complète de tous les services
- **2025-10-23**: ✅ Ajout sections Document Management (Paperless-ngx, Paperless AI)
- **2025-10-23**: ✅ Documentation NeuTTS (API + UI synthèse vocale)
- **2025-10-23**: ✅ Dashy remis en marche avec configuration unifiée (10 sections, 50+ services)
- **2025-10-21**: ✅ Glances déployé en remplacement de Netdata (incident serveur: Netdata incompatible avec 59 conteneurs)
- **2025-10-21**: ✅ Sécurisation CRITIQUE complétée - Portainer, Glances, Loki maintenant protégés (HTTPS + Basic Auth + localhost)
- **2025-10-21**: Documentation complète des outils d'infrastructure (Netdata, Dozzle, Portainer)
- **2025-10-21**: Identification et correction des problèmes de sécurité critiques
- **2025-10-21**: Déploiement stack collaboration complète (Nextcloud, Rocket.Chat, Jitsi Meet)
- **2025-10-21**: Infrastructure bases de données partagées (MongoDB, PostgreSQL, Redis)
- **2025-10-21**: Intégration ONLYOFFICE avec Nextcloud pour co-édition documents
- **2025-10-21**: Configuration auto-start/stop pour 22 services (optimisation RAM)
- **2025-10-21**: Configuration HTTPS pour Dozzle, WhisperX, Dashy
- **2025-10-20**: Ajout Faster-Whisper Queue API avec système RQ
- **2025-10-20**: Déploiement stack Grafana + Prometheus + Loki

---

*Documentation générée avec MkDocs Material - [https://docs.srv759970.hstgr.cloud](https://docs.srv759970.hstgr.cloud)*
