# Impro Manager Next.js - Quick Start Guide

Quick reference for deploying Impro Manager Next.js on Hostinger VPS.

---

## Prerequisites Checklist

- [ ] Server: root@69.62.108.82 accessible via SSH
- [ ] Docker & Docker Compose installed
- [ ] Nginx installed and configured
- [ ] rclone configured with Dropbox
- [ ] Music mount active at `/opt/impro-manager/music`
- [ ] SSL certificate for `zimprobagnais.srv759970.hstgr.cloud`
- [ ] Basic Auth configured (julien/DevAccess2025)

---

## Initial Server Setup

### 1. Run Setup Script on Server

```bash
# Connect to server
ssh root@69.62.108.82

# Create working directory
mkdir -p /opt/impro-manager/nextjs-app
cd /opt/impro-manager/nextjs-app

# Download and run setup script
curl -O https://your-repo/setup-server.sh
chmod +x setup-server.sh
./setup-server.sh
```

Or manually install:

```bash
apt update && apt install -y docker.io docker-compose nginx certbot python3-certbot-nginx
curl https://rclone.org/install.sh | bash
```

---

## Deploy Next.js Application

### 2. Transfer Files from Local Machine

**From Windows PowerShell or Git Bash:**

```bash
# Navigate to your Next.js project
cd "C:\path\to\impro-manager-nextjs"

# Transfer application files
scp -r app components lib server public package*.json next.config.ts root@69.62.108.82:/opt/impro-manager/nextjs-app/

# Transfer Docker configuration
scp -r docker root@69.62.108.82:/opt/impro-manager/nextjs-app/

# OR use rsync for better performance
rsync -avz --progress --exclude 'node_modules' --exclude '.next' \
  ./ root@69.62.108.82:/opt/impro-manager/nextjs-app/
```

### 3. Configure Environment Variables

**On server:**

```bash
cd /opt/impro-manager/nextjs-app

# Copy environment template
cp docker/.env.example .env.local

# Edit environment variables
nano .env.local
```

Ensure these are set:

```bash
NODE_ENV=production
NEXT_PUBLIC_API_URL=http://impro-backend:3002
NEXT_PUBLIC_SOCKET_URL=http://impro-backend:3002
```

### 4. Update next.config.ts

Ensure `next.config.ts` has:

```typescript
const nextConfig = {
  output: 'standalone',  // REQUIRED for Docker
  // ... other config
}
```

Or copy the example:

```bash
cp docker/next.config.example.ts next.config.ts
```

### 5. Build and Deploy

```bash
cd /opt/impro-manager/nextjs-app

# Make deploy script executable
chmod +x docker/deploy.sh

# Run deployment
./docker/deploy.sh
```

**The script will:**
- Build Docker images
- Stop old containers
- Start new containers
- Run health checks
- Display status

---

## Configure Nginx

### 6. Setup Nginx Reverse Proxy

```bash
# Copy Nginx configuration
cp /opt/impro-manager/nextjs-app/docker/nginx.conf /etc/nginx/sites-available/zimprobagnais

# Create symlink
ln -sf /etc/nginx/sites-available/zimprobagnais /etc/nginx/sites-enabled/

# Test configuration
nginx -t

# Reload Nginx
systemctl reload nginx
```

### 7. SSL Certificate (if not exists)

```bash
# Stop Nginx temporarily
systemctl stop nginx

# Obtain certificate
certbot certonly --standalone -d zimprobagnais.srv759970.hstgr.cloud

# Start Nginx
systemctl start nginx

# OR use nginx plugin
certbot certonly --nginx -d zimprobagnais.srv759970.hstgr.cloud
```

---

## Verify Deployment

### 8. Test Services

```bash
# Check containers are running
docker ps | grep impro

# Expected output:
# impro-nextjs    Up 2 minutes    0.0.0.0:3001->3001/tcp
# impro-backend   Up 2 minutes    0.0.0.0:3002->3002/tcp

# Test health endpoints
curl http://localhost:3001/api/health
curl http://localhost:3002/api/health

# Test public URL (with Basic Auth)
curl -u julien:DevAccess2025 https://zimprobagnais.srv759970.hstgr.cloud/api/health

# Check logs
docker logs impro-nextjs --tail 50
docker logs impro-backend --tail 50
```

### 9. Verify Music Access

```bash
# Check music mount
ls /opt/impro-manager/music

# Check if backend can access music
docker exec impro-backend ls /app/music

# Test music API endpoint
curl -u julien:DevAccess2025 https://zimprobagnais.srv759970.hstgr.cloud/backend/api/music | jq '.[:3]'
```

---

## Common Operations

### View Logs

```bash
# Follow all logs
docker-compose -f /opt/impro-manager/nextjs-app/docker/docker-compose.yml logs -f

# Specific service
docker logs impro-nextjs -f
docker logs impro-backend -f

# Last 100 lines
docker logs impro-backend --tail 100
```

### Restart Services

```bash
cd /opt/impro-manager/nextjs-app

# Restart all
docker-compose -f docker/docker-compose.yml restart

# Restart specific service
docker restart impro-nextjs
docker restart impro-backend
```

### Update Application

```bash
cd /opt/impro-manager/nextjs-app

# Pull latest code (if git repo)
git pull origin main

# Rebuild and redeploy
./docker/deploy.sh --no-cache
```

### Stop Services

```bash
cd /opt/impro-manager/nextjs-app
docker-compose -f docker/docker-compose.yml down
```

---

## Troubleshooting

### Container won't start

```bash
# Check logs
docker logs impro-nextjs --tail 100
docker logs impro-backend --tail 100

# Check ports
netstat -tulpn | grep -E ':(3001|3002)'

# Remove old containers and rebuild
docker-compose -f docker/docker-compose.yml down
docker-compose -f docker/docker-compose.yml up -d --force-recreate
```

### 502 Bad Gateway

```bash
# Check if containers are running
docker ps | grep impro

# Test container endpoints directly
curl http://localhost:3001/api/health
curl http://localhost:3002/api/health

# Check Nginx error log
tail -f /var/log/nginx/impro-manager-error.log

# Restart Nginx
systemctl restart nginx
```

### Socket.IO not connecting

```bash
# Check backend logs
docker logs impro-backend | grep -i socket

# Test Socket.IO endpoint
curl http://localhost:3002/socket.io/?EIO=4&transport=polling

# Check Nginx WebSocket config
nginx -T | grep -A 10 "location /socket.io"
```

### Music files not accessible

```bash
# Check rclone mount
systemctl status rclone-music-mount

# Restart mount
systemctl restart rclone-music-mount

# Verify mount
ls /opt/impro-manager/music

# Check container volume mount
docker inspect impro-backend | grep -A 10 Mounts
```

---

## Important URLs

| Service | URL | Auth Required |
|---------|-----|---------------|
| Public App | https://zimprobagnais.srv759970.hstgr.cloud | Yes (julien/DevAccess2025) |
| Frontend (local) | http://localhost:3001 | No |
| Backend (local) | http://localhost:3002 | No |
| Health Check | https://zimprobagnais.srv759970.hstgr.cloud/api/health | No |

---

## Auto-start Integration (Optional)

Add to docker-autostart for automatic wake-on-access:

```bash
# Edit config
nano /opt/docker-autostart/config.json

# Add service
{
  "services": {
    "zimprobagnais.srv759970.hstgr.cloud": {
      "name": "Impro Manager Next.js",
      "composeDir": "/opt/impro-manager/nextjs-app/docker",
      "proxyPort": 3001,
      "theme": "matrix",
      "containers": ["impro-nextjs", "impro-backend"],
      "timeout": 180
    }
  }
}

# Restart service
systemctl restart docker-autostart
```

---

## Resource Usage

Expected resource usage:

- **Frontend (Next.js):** ~100-200 MB RAM
- **Backend (Express):** ~150-300 MB RAM
- **Total:** ~250-500 MB RAM
- **Disk:** ~500 MB (images + volumes)

Check with:

```bash
docker stats impro-nextjs impro-backend
```

---

## Backup

### Backup persistent data

```bash
cd /opt/impro-manager
tar -czf backup-$(date +%Y%m%d-%H%M%S).tar.gz data uploads

# List backups
ls -lh backup-*.tar.gz
```

### Restore from backup

```bash
cd /opt/impro-manager
tar -xzf backup-20251027-120000.tar.gz
./nextjs-app/docker/deploy.sh
```

---

## Support

For detailed documentation, see:
- **Full Guide:** `/opt/impro-manager/nextjs-app/docker/README_DOCKER.md`
- **Docker Compose:** `/opt/impro-manager/nextjs-app/docker/docker-compose.yml`
- **Nginx Config:** `/opt/impro-manager/nextjs-app/docker/nginx.conf`

---

**Last Updated:** 27 octobre 2025
