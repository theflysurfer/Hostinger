# Impro Manager Next.js - Docker Deployment Guide

**Version:** 2.0 (Next.js)
**Date:** 27 octobre 2025
**Server:** root@69.62.108.82
**Path:** `/opt/impro-manager/nextjs-app/`

---

## Architecture

### Stack Technique

**Frontend:**
- Next.js 15 (App Router)
- React 19
- Tailwind CSS 4.0
- shadcn/ui components
- Socket.IO Client

**Backend:**
- Express.js 4.x
- Socket.IO 4.x (WebSocket)
- ffmpeg (audio processing)
- music-metadata (metadata extraction)

**Infrastructure:**
- Docker + Docker Compose
- Nginx (reverse proxy)
- Let's Encrypt SSL
- Dropbox (rclone music mount)

### Services Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Internet (HTTPS)                    │
│            zimprobagnais.srv759970.hstgr.cloud       │
└──────────────────┬──────────────────────────────────┘
                   │
            ┌──────▼──────┐
            │    Nginx    │
            │   Port 443  │ (SSL, Basic Auth)
            └──────┬──────┘
                   │
        ┌──────────┴──────────┐
        │                     │
   ┌────▼─────┐        ┌─────▼──────┐
   │ Next.js  │        │  Express   │
   │ Port 3001│◄──────►│ Port 3002  │
   │ Frontend │        │  Backend   │
   └──────────┘        └─────┬──────┘
                             │
                        ┌────▼─────┐
                        │  Music   │
                        │ (rclone) │
                        └──────────┘
```

---

## File Structure

```
/opt/impro-manager/nextjs-app/
├── docker/
│   ├── Dockerfile              # Next.js production build
│   ├── Dockerfile.server       # Express backend
│   ├── docker-compose.yml      # Production orchestration
│   ├── .dockerignore           # Build optimization
│   ├── deploy.sh               # Deployment script
│   ├── nginx.conf              # Nginx configuration
│   └── README_DOCKER.md        # This file
├── app/                        # Next.js app directory
├── components/                 # React components
├── server/                     # Express backend
├── public/                     # Static assets
├── package.json
└── next.config.ts
```

---

## Prerequisites

### 1. Next.js Configuration

Add to `next.config.ts`:

```typescript
const nextConfig = {
  output: 'standalone',  // Required for Docker

  // Environment variables
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
    NEXT_PUBLIC_SOCKET_URL: process.env.NEXT_PUBLIC_SOCKET_URL,
  },
}

export default nextConfig
```

### 2. Create API Health Check

Create `app/api/health/route.ts`:

```typescript
export async function GET() {
  return Response.json({
    status: 'ok',
    service: 'impro-manager-nextjs',
    timestamp: new Date().toISOString()
  })
}
```

### 3. Backend Health Check

Create `server/routes/health.js`:

```javascript
router.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'impro-manager-backend',
    timestamp: new Date().toISOString()
  })
})
```

### 4. Music Mount (rclone + Dropbox)

```bash
# Verify rclone mount is active
systemctl status rclone-music-mount

# If not mounted:
systemctl start rclone-music-mount

# Verify music files
ls /opt/impro-manager/music
```

---

## Deployment Steps

### Step 1: Initial Setup on Server

```bash
# Connect to server
ssh root@69.62.108.82

# Create project directory
mkdir -p /opt/impro-manager/nextjs-app
cd /opt/impro-manager/nextjs-app

# Create necessary directories
mkdir -p music data uploads logs
```

### Step 2: Transfer Files

**From your Windows machine:**

```bash
# Navigate to your Next.js project
cd "C:\path\to\impro-manager-nextjs"

# Transfer files (exclude node_modules, .next)
scp -r app components lib server public package*.json next.config.ts root@69.62.108.82:/opt/impro-manager/nextjs-app/

# Transfer Docker configuration
scp -r docker root@69.62.108.82:/opt/impro-manager/nextjs-app/
```

### Step 3: Build and Deploy

**On the server:**

```bash
cd /opt/impro-manager/nextjs-app

# Make deploy script executable
chmod +x docker/deploy.sh

# Run deployment
./docker/deploy.sh
```

The deployment script will:
1. Pull latest changes (if git repo)
2. Build Docker images
3. Stop old containers
4. Start new containers
5. Wait for services to be ready
6. Run health checks
7. Display status

### Step 4: Configure Nginx

```bash
# Copy Nginx configuration
cp docker/nginx.conf /etc/nginx/sites-available/zimprobagnais

# Create symlink
ln -sf /etc/nginx/sites-available/zimprobagnais /etc/nginx/sites-enabled/

# Test configuration
nginx -t

# Reload Nginx
systemctl reload nginx
```

### Step 5: SSL Certificate (if not already configured)

```bash
# Obtain Let's Encrypt certificate
certbot certonly --nginx -d zimprobagnais.srv759970.hstgr.cloud

# Certificates will be saved to:
# /etc/letsencrypt/live/zimprobagnais.srv759970.hstgr.cloud/
```

### Step 6: Verify Deployment

```bash
# Check containers are running
docker ps | grep impro

# Check logs
docker logs impro-nextjs --tail 50
docker logs impro-backend --tail 50

# Test endpoints
curl http://localhost:3001/api/health
curl http://localhost:3002/api/health

# Test public URL (with Basic Auth)
curl -u julien:DevAccess2025 https://zimprobagnais.srv759970.hstgr.cloud/api/health
```

---

## Docker Management

### Container Operations

```bash
cd /opt/impro-manager/nextjs-app

# Start containers
docker-compose -f docker/docker-compose.yml up -d

# Stop containers
docker-compose -f docker/docker-compose.yml down

# Restart containers
docker-compose -f docker/docker-compose.yml restart

# View logs (follow mode)
docker-compose -f docker/docker-compose.yml logs -f

# View logs for specific service
docker logs impro-nextjs -f
docker logs impro-backend -f

# Check status
docker-compose -f docker/docker-compose.yml ps
```

### Rebuild and Deploy

```bash
# Full rebuild (no cache)
./docker/deploy.sh --no-cache

# Rebuild with fresh base images
./docker/deploy.sh --pull

# Quick restart (no rebuild)
docker-compose -f docker/docker-compose.yml restart
```

### Resource Management

```bash
# Check resource usage
docker stats impro-nextjs impro-backend

# Remove unused images
docker image prune -a

# Remove unused volumes
docker volume prune

# Full cleanup (careful!)
docker system prune -a --volumes
```

---

## Environment Variables

### Frontend (.env.local)

```bash
NODE_ENV=production
NEXT_PUBLIC_API_URL=http://impro-backend:3002
NEXT_PUBLIC_SOCKET_URL=http://impro-backend:3002
NEXT_TELEMETRY_DISABLED=1
```

### Backend (.env)

```bash
NODE_ENV=production
SERVER_PORT=3002
FRONTEND_URL=http://impro-nextjs:3001
MUSIC_PATH=/app/music
DATA_PATH=/app/data
UPLOAD_PATH=/app/uploads
```

---

## Troubleshooting

### Container won't start

```bash
# Check logs
docker logs impro-nextjs --tail 100
docker logs impro-backend --tail 100

# Check if ports are available
netstat -tulpn | grep -E ':(3001|3002)'

# Inspect container
docker inspect impro-nextjs
```

### Health check fails

```bash
# Test health endpoints directly
docker exec impro-nextjs node -e "require('http').get('http://localhost:3001/api/health', r => console.log(r.statusCode))"

# Check container network
docker network inspect impro-network
```

### Music files not accessible

```bash
# Check rclone mount
systemctl status rclone-music-mount
ls /opt/impro-manager/music

# Restart rclone
systemctl restart rclone-music-mount

# Check volume mounts
docker inspect impro-backend | grep Mounts -A 20
```

### Socket.IO connection issues

```bash
# Check backend logs for Socket.IO errors
docker logs impro-backend | grep -i socket

# Test Socket.IO endpoint
curl -i http://localhost:3002/socket.io/?EIO=4&transport=polling

# Check Nginx WebSocket config
nginx -T | grep -A 10 "location /socket.io"
```

### Nginx 502 Bad Gateway

```bash
# Check containers are running
docker ps | grep impro

# Test container endpoints
curl http://localhost:3001/api/health
curl http://localhost:3002/api/health

# Check Nginx error logs
tail -f /var/log/nginx/impro-manager-error.log

# Test Nginx config
nginx -t
```

### High memory usage

```bash
# Check resource usage
docker stats --no-stream

# Restart specific service
docker-compose -f docker/docker-compose.yml restart backend

# Check for memory leaks in logs
docker logs impro-backend | grep -i memory
```

---

## Auto-start Integration

### Add to docker-autostart config

Edit `/opt/docker-autostart/config.json`:

```json
{
  "services": {
    "zimprobagnais.srv759970.hstgr.cloud": {
      "name": "Impro Manager Next.js",
      "composeDir": "/opt/impro-manager/nextjs-app/docker",
      "proxyPort": 3001,
      "theme": "matrix",
      "containers": ["impro-nextjs", "impro-backend"],
      "timeout": 180
    }
  }
}
```

### Restart auto-start service

```bash
systemctl restart docker-autostart
journalctl -u docker-autostart -f
```

---

## Maintenance

### Update Application

```bash
cd /opt/impro-manager/nextjs-app

# Pull latest changes
git pull origin main

# Rebuild and deploy
./docker/deploy.sh --no-cache
```

### Backup Data

```bash
# Backup persistent data
cd /opt/impro-manager
tar -czf backup-$(date +%Y%m%d).tar.gz data uploads

# Backup to remote location
rsync -avz --progress backup-*.tar.gz user@backup-server:/backups/impro-manager/
```

### View Logs

```bash
# Application logs
docker logs impro-nextjs --since 1h
docker logs impro-backend --since 1h

# Nginx logs
tail -f /var/log/nginx/impro-manager-access.log
tail -f /var/log/nginx/impro-manager-error.log

# Docker logs
journalctl -u docker -f
```

### Security Updates

```bash
# Update base images
docker-compose -f docker/docker-compose.yml pull

# Rebuild with updated images
./docker/deploy.sh --pull

# Update system packages
apt update && apt upgrade -y
```

---

## Performance Optimization

### Enable Gzip Compression in Nginx

Already configured in `nginx.conf` via Let's Encrypt options.

### Next.js Image Optimization

Ensure `next/image` is used for all images:

```tsx
import Image from 'next/image'

<Image
  src="/music-icon.png"
  width={64}
  height={64}
  alt="Music"
/>
```

### Cache Static Assets

Nginx automatically caches `_next/static` files for 1 year.

### Docker Image Size Optimization

Current configuration uses:
- Multi-stage builds
- Alpine Linux (minimal base)
- `.dockerignore` to exclude unnecessary files

---

## Monitoring

### Container Health

```bash
# Check health status
docker inspect --format='{{.State.Health.Status}}' impro-nextjs
docker inspect --format='{{.State.Health.Status}}' impro-backend

# View health check logs
docker inspect --format='{{json .State.Health}}' impro-nextjs | jq
```

### Resource Usage

```bash
# Real-time stats
docker stats impro-nextjs impro-backend

# Historical stats (if prometheus/grafana configured)
# Access Grafana dashboard
```

### Uptime

```bash
# Check container uptime
docker ps --format "table {{.Names}}\t{{.Status}}"

# View restart count
docker inspect --format='{{.RestartCount}}' impro-nextjs
```

---

## URLs and Access

### Internal URLs (within Docker network)

- Frontend: `http://impro-nextjs:3001`
- Backend: `http://impro-backend:3002`

### Host URLs (on server)

- Frontend: `http://localhost:3001`
- Backend: `http://localhost:3002`

### Public URL

- **URL:** `https://zimprobagnais.srv759970.hstgr.cloud`
- **Credentials:** julien / DevAccess2025

---

## Rollback Procedure

If deployment fails:

```bash
# Stop new containers
docker-compose -f docker/docker-compose.yml down

# Check previous images
docker images | grep impro

# Start with previous image tag
docker-compose -f docker/docker-compose.yml up -d --no-deps --build

# Or restore from backup
# ... restore data and rebuild
```

---

## Support

### Logs Location

- **Docker logs:** `docker logs <container-name>`
- **Nginx logs:** `/var/log/nginx/impro-manager-*.log`
- **Application logs:** `/opt/impro-manager/logs/`

### Common Issues

1. **Port already in use:** Check with `netstat -tulpn | grep 3001`
2. **Music not loading:** Verify rclone mount `ls /opt/impro-manager/music`
3. **Socket.IO disconnect:** Check backend logs and Nginx WebSocket config
4. **502 Bad Gateway:** Verify containers are running and healthy

---

## Additional Configuration

### Custom Domain (if needed)

```bash
# Update Nginx server_name
nano /etc/nginx/sites-available/zimprobagnais

# Replace:
server_name zimprobagnais.srv759970.hstgr.cloud;
# With:
server_name impro.yourdomain.com;

# Get new SSL certificate
certbot certonly --nginx -d impro.yourdomain.com

# Update nginx.conf SSL paths
nano /etc/nginx/sites-available/zimprobagnais

# Reload Nginx
nginx -t && systemctl reload nginx
```

### Enable Debug Logging

**Next.js:**
```bash
# Add to docker-compose.yml under nextjs environment:
- DEBUG=*
```

**Backend:**
```bash
# Add to docker-compose.yml under backend environment:
- DEBUG=express:*,socket.io:*
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0 | 2025-10-27 | Initial Next.js deployment documentation |

---

**Maintained by:** DevOps Team
**Last Updated:** 27 octobre 2025
