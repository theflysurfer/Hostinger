import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  // REQUIRED: Enable standalone output for Docker deployment
  // This creates a minimal .next/standalone folder with only necessary files
  output: 'standalone',

  // OPTIONAL: Configure base path if serving from subdirectory
  // basePath: '/impro',

  // OPTIONAL: Asset prefix for CDN
  // assetPrefix: 'https://cdn.example.com',

  // Environment variables exposed to browser
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3002',
    NEXT_PUBLIC_SOCKET_URL: process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3002',
  },

  // Image optimization configuration
  images: {
    domains: ['localhost'],
    // If using external image sources, add them here
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.srv759970.hstgr.cloud',
      },
    ],
  },

  // Webpack configuration (if needed for custom loaders)
  webpack: (config, { isServer }) => {
    // Add custom webpack config here if needed
    // Example: Exclude certain modules from server bundle
    if (isServer) {
      config.externals.push({
        'bufferutil': 'bufferutil',
        'utf-8-validate': 'utf-8-validate',
      })
    }

    return config
  },

  // Experimental features (optional)
  experimental: {
    // Enable Server Actions
    serverActions: {
      bodySizeLimit: '2mb',
    },
  },

  // Disable telemetry in production
  // Note: This is also set via ENV variable in Dockerfile
  // productionBrowserSourceMaps: false, // Disable source maps in production

  // Redirects (if needed)
  async redirects() {
    return [
      // Example: Redirect old Vue.js routes to new Next.js routes
      // {
      //   source: '/old-path',
      //   destination: '/new-path',
      //   permanent: true,
      // },
    ]
  },

  // Rewrites for API proxy (if needed)
  async rewrites() {
    return [
      // Example: Proxy backend API calls
      // {
      //   source: '/backend/api/:path*',
      //   destination: 'http://impro-backend:3002/api/:path*',
      // },
    ]
  },

  // Headers configuration
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ]
  },
}

export default nextConfig
