#!/bin/bash

# Impro Manager Next.js Deployment Script
# Usage: ./deploy.sh [--no-cache] [--pull]

set -e  # Exit on error

echo "======================================"
echo "  Impro Manager Next.js Deployment"
echo "======================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Parse arguments
NO_CACHE=""
PULL=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --no-cache)
      NO_CACHE="--no-cache"
      shift
      ;;
    --pull)
      PULL="--pull"
      shift
      ;;
    *)
      echo -e "${RED}Unknown option: $1${NC}"
      exit 1
      ;;
  esac
done

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Error: docker-compose not found${NC}"
    exit 1
fi

# Navigate to the project directory
cd /opt/impro-manager/nextjs-app

echo -e "${BLUE}[1/6] Pulling latest changes from git...${NC}"
if [ -d .git ]; then
    git pull origin main || git pull origin master || echo -e "${YELLOW}Warning: Could not pull from git${NC}"
else
    echo -e "${YELLOW}Not a git repository, skipping...${NC}"
fi

echo ""
echo -e "${BLUE}[2/6] Building Docker images...${NC}"
docker-compose -f docker/docker-compose.yml build $NO_CACHE $PULL

echo ""
echo -e "${BLUE}[3/6] Stopping old containers...${NC}"
docker-compose -f docker/docker-compose.yml down

echo ""
echo -e "${BLUE}[4/6] Starting new containers...${NC}"
docker-compose -f docker/docker-compose.yml up -d

echo ""
echo -e "${BLUE}[5/6] Waiting for services to be ready...${NC}"
sleep 10

# Wait for backend to be healthy
echo -n "Waiting for backend"
for i in {1..30}; do
    if curl -sf http://localhost:3002/api/health > /dev/null 2>&1; then
        echo -e " ${GREEN}OK${NC}"
        break
    fi
    echo -n "."
    sleep 2
done

# Wait for frontend to be healthy
echo -n "Waiting for frontend"
for i in {1..30}; do
    if curl -sf http://localhost:3001/api/health > /dev/null 2>&1; then
        echo -e " ${GREEN}OK${NC}"
        break
    fi
    echo -n "."
    sleep 2
done

echo ""
echo -e "${BLUE}[6/6] Running health checks...${NC}"

# Check backend health
BACKEND_HEALTH=$(curl -sf http://localhost:3002/api/health || echo "FAIL")
if [ "$BACKEND_HEALTH" != "FAIL" ]; then
    echo -e "${GREEN}✓ Backend is healthy${NC} (http://localhost:3002)"
else
    echo -e "${RED}✗ Backend health check failed${NC}"
    echo "Backend logs:"
    docker logs impro-backend --tail 20
    exit 1
fi

# Check frontend health
FRONTEND_HEALTH=$(curl -sf http://localhost:3001/api/health || echo "FAIL")
if [ "$FRONTEND_HEALTH" != "FAIL" ]; then
    echo -e "${GREEN}✓ Frontend is healthy${NC} (http://localhost:3001)"
else
    echo -e "${RED}✗ Frontend health check failed${NC}"
    echo "Frontend logs:"
    docker logs impro-nextjs --tail 20
    exit 1
fi

# Show running containers
echo ""
echo -e "${BLUE}Running containers:${NC}"
docker-compose -f docker/docker-compose.yml ps

echo ""
echo "======================================"
echo -e "${GREEN}  Deployment completed successfully!${NC}"
echo "======================================"
echo ""
echo "Services:"
echo "  - Frontend: http://localhost:3001"
echo "  - Backend:  http://localhost:3002"
echo "  - Public:   https://zimprobagnais.srv759970.hstgr.cloud"
echo ""
echo "Useful commands:"
echo "  - View logs:     docker-compose -f docker/docker-compose.yml logs -f"
echo "  - Stop services: docker-compose -f docker/docker-compose.yml down"
echo "  - Restart:       docker-compose -f docker/docker-compose.yml restart"
echo ""
