#!/bin/bash

# Impro Manager Next.js - Server Setup Script
# Run this script on the server (root@69.62.108.82) to prepare the environment

set -e  # Exit on error

echo "======================================"
echo "  Impro Manager Next.js Setup"
echo "======================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: This script must be run as root${NC}"
    exit 1
fi

echo -e "${BLUE}[1/8] Creating project directories...${NC}"
mkdir -p /opt/impro-manager/nextjs-app
mkdir -p /opt/impro-manager/music
mkdir -p /opt/impro-manager/data
mkdir -p /opt/impro-manager/uploads
mkdir -p /opt/impro-manager/logs

echo -e "${GREEN}✓ Directories created${NC}"

echo ""
echo -e "${BLUE}[2/8] Checking Docker installation...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker not found. Installing...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}✓ Docker installed${NC}"
else
    echo -e "${GREEN}✓ Docker is already installed${NC}"
fi

echo ""
echo -e "${BLUE}[3/8] Checking Docker Compose installation...${NC}"
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Docker Compose not found. Installing...${NC}"
    COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep 'tag_name' | cut -d'"' -f4)
    curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✓ Docker Compose installed${NC}"
else
    echo -e "${GREEN}✓ Docker Compose is already installed${NC}"
fi

echo ""
echo -e "${BLUE}[4/8] Checking Nginx installation...${NC}"
if ! command -v nginx &> /dev/null; then
    echo -e "${YELLOW}Nginx not found. Installing...${NC}"
    apt update
    apt install -y nginx
    systemctl enable nginx
    systemctl start nginx
    echo -e "${GREEN}✓ Nginx installed${NC}"
else
    echo -e "${GREEN}✓ Nginx is already installed${NC}"
fi

echo ""
echo -e "${BLUE}[5/8] Checking Certbot installation...${NC}"
if ! command -v certbot &> /dev/null; then
    echo -e "${YELLOW}Certbot not found. Installing...${NC}"
    apt install -y certbot python3-certbot-nginx
    echo -e "${GREEN}✓ Certbot installed${NC}"
else
    echo -e "${GREEN}✓ Certbot is already installed${NC}"
fi

echo ""
echo -e "${BLUE}[6/8] Checking rclone installation...${NC}"
if ! command -v rclone &> /dev/null; then
    echo -e "${YELLOW}rclone not found. Installing...${NC}"
    curl https://rclone.org/install.sh | bash
    echo -e "${GREEN}✓ rclone installed${NC}"
else
    echo -e "${GREEN}✓ rclone is already installed${NC}"
fi

echo ""
echo -e "${BLUE}[7/8] Checking rclone music mount...${NC}"
if systemctl is-active --quiet rclone-music-mount; then
    echo -e "${GREEN}✓ rclone music mount is active${NC}"
else
    echo -e "${YELLOW}⚠ rclone music mount is NOT active${NC}"
    echo "  You need to configure rclone and start the mount service"
    echo "  See: /opt/impro-manager/nextjs-app/docker/README_DOCKER.md"
fi

# Check if music directory has files
MUSIC_COUNT=$(ls -1 /opt/impro-manager/music 2>/dev/null | wc -l)
if [ "$MUSIC_COUNT" -gt 0 ]; then
    echo -e "${GREEN}✓ Music directory contains $MUSIC_COUNT items${NC}"
else
    echo -e "${YELLOW}⚠ Music directory is empty${NC}"
fi

echo ""
echo -e "${BLUE}[8/8] Setting up Basic Auth (if not exists)...${NC}"
if [ ! -f /etc/nginx/snippets/basic-auth.conf ]; then
    echo "Creating Basic Auth configuration..."

    # Create .htpasswd file
    apt install -y apache2-utils
    htpasswd -cb /etc/nginx/.htpasswd julien DevAccess2025

    # Create snippet
    cat > /etc/nginx/snippets/basic-auth.conf <<EOF
auth_basic "Restricted Access";
auth_basic_user_file /etc/nginx/.htpasswd;
EOF

    echo -e "${GREEN}✓ Basic Auth configured${NC}"
    echo "  Username: julien"
    echo "  Password: DevAccess2025"
else
    echo -e "${GREEN}✓ Basic Auth already configured${NC}"
fi

echo ""
echo "======================================"
echo -e "${GREEN}  Setup completed successfully!${NC}"
echo "======================================"
echo ""
echo "Next steps:"
echo "1. Transfer your Next.js project files to /opt/impro-manager/nextjs-app/"
echo "2. Configure rclone for Dropbox music mount (if not done)"
echo "3. Run the deployment script: ./deploy.sh"
echo "4. Configure Nginx with the provided nginx.conf"
echo "5. Obtain SSL certificate if not already done"
echo ""
echo "For detailed instructions, see:"
echo "  /opt/impro-manager/nextjs-app/docker/README_DOCKER.md"
echo ""
