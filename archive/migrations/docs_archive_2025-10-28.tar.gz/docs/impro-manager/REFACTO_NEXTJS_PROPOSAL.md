# 🚀 Proposition de Refacto : Next.js 15 + Tailwind + shadcn/ui

**Date:** 27 octobre 2025
**Projet:** Impro Manager v2.0
**Statut:** Proposition - Phase d'évaluation

---

## 📊 Analyse Stack Actuelle

### Stack Technique Existante

**Frontend:**
- Vue.js 3.4.15 + Vue Router
- Vite 5.0.11 (bundler)
- CSS vanilla (5.9 KB style.css)
- Font Awesome 6.5.1
- Socket.IO Client 4.7.4
- WaveSurfer.js 7.11.0 (audio waveforms)

**Backend:**
- Express.js 4.18.2
- Socket.IO 4.8.1 (WebSocket temps réel)
- Multer (upload fichiers)
- ytdl-core (download YouTube)
- fluent-ffmpeg (traitement audio)
- music-metadata (extraction métadonnées)

**Composants Frontend (15 fichiers Vue):**
```
components/
├── Home.vue (5.2 KB)
├── MCInterface.vue (26.3 KB) ⚠️ Complexe
├── SoundInterface.vue (38.2 KB) ⚠️ Très complexe
├── MCLive.vue (10 KB)
├── SoundLive.vue (13.7 KB)
├── LineEditor.vue (10.1 KB)
├── MusicLibrary.vue (9.8 KB)
├── MusicAssignment.vue (9.2 KB)
├── MusicAssignmentPanel.vue (12.5 KB)
├── WaveformPlayer.vue (8.5 KB)
└── music/
    ├── MusicCard.vue
    ├── MusicFilters.vue
    └── AudioPlayer.vue

views/
└── YouTubeDownloader.vue (18.9 KB)
```

**Backend API (9 fichiers JS):**
```
backend/
├── app.js (19.4 KB)
├── controllers/
│   ├── matchController.js (4.9 KB)
│   └── personnelController.js (5.2 KB)
└── routes/
    ├── matchRoutes.js
    ├── personnelRoutes.js
    ├── templateRoutes.js
    └── youtubeRoutes.js (6.7 KB)
```

### Points Forts
✅ Architecture claire séparation Frontend/Backend
✅ WebSocket temps réel fonctionnel
✅ Bibliothèque musicale opérationnelle (777+ pistes)
✅ Traitement audio avancé (waveforms, métadonnées)
✅ Download YouTube intégré

### Points Faibles
❌ CSS vanilla non scalable
❌ Composants monolithiques (38 KB SoundInterface.vue)
❌ Pas de système de design cohérent
❌ Maintenance complexe des gros composants
❌ Pas de SSR (SEO limité si besoin futur)

---

## 🎯 Proposition : Next.js 15 + Tailwind + shadcn/ui

### Nouvelle Stack Technique

**Framework:**
- **Next.js 15** (App Router) - React Server Components
- **React 19** (RC)
- **TypeScript 5.3+** (migration progressive)

**Styling:**
- **Tailwind CSS 4.0** (Beta) - Utility-first
- **shadcn/ui** - Composants accessibles headless
- **Radix UI** (via shadcn) - Primitives accessibles
- **CVA** (class-variance-authority) - Variants

**State Management:**
- **Zustand 4.5** (global state léger) - Remplace Vue reactivity
- **React Query v5** (server state) - Cache API
- **Socket.IO Client** (conservé pour WebSocket)

**Audio:**
- **WaveSurfer.js** (conservé) - Waveforms
- **Howler.js** (optionnel) - Audio playback avancé

**Backend:**
- **Next.js API Routes** (remplacement partiel Express)
- **Express.js standalone** (pour Socket.IO + endpoints lourds)
- **tRPC** (optionnel) - Type-safe API

---

## 🏗️ Architecture Proposée

### Structure Next.js App Router

```
impro-manager-nextjs/
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   └── layout.tsx
│   ├── (dashboard)/
│   │   ├── layout.tsx          # Layout avec navigation
│   │   ├── page.tsx            # Home
│   │   ├── mc/
│   │   │   ├── prep/           # MC Interface Préparation
│   │   │   └── live/           # MC Live
│   │   ├── sound/
│   │   │   ├── prep/           # Sound Interface Préparation
│   │   │   └── live/           # Sound Live
│   │   ├── library/            # Bibliothèque musicale
│   │   ├── youtube/            # YouTube Downloader
│   │   └── admin/              # Admin panel
│   ├── api/
│   │   ├── matches/route.ts
│   │   ├── music/route.ts
│   │   └── personnel/route.ts
│   └── layout.tsx              # Root layout
├── components/
│   ├── ui/                     # shadcn components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── dialog.tsx
│   │   ├── dropdown-menu.tsx
│   │   └── ...
│   ├── music/
│   │   ├── music-card.tsx
│   │   ├── music-filters.tsx
│   │   ├── audio-player.tsx
│   │   └── waveform-player.tsx
│   ├── match/
│   │   ├── line-editor.tsx
│   │   ├── match-timer.tsx
│   │   └── score-board.tsx
│   └── shared/
│       ├── navbar.tsx
│       └── sidebar.tsx
├── lib/
│   ├── socket.ts               # Socket.IO client setup
│   ├── api.ts                  # API client
│   └── utils.ts                # Utilities
├── hooks/
│   ├── use-socket.ts
│   ├── use-music.ts
│   └── use-match.ts
├── stores/
│   ├── match-store.ts          # Zustand store
│   ├── music-store.ts
│   └── user-store.ts
└── server/                     # Express backend standalone
    ├── index.js                # Express + Socket.IO
    ├── controllers/
    └── routes/
```

### Déploiement Hybrid

**Option 1: Monorepo**
```
services:
  nextjs:
    build: .
    ports: ["3001:3000"]
    environment:
      - SOCKET_SERVER_URL=http://localhost:3002

  backend:
    build: ./server
    ports: ["3002:3002"]
    # Express + Socket.IO standalone
```

**Option 2: Next.js Full**
```
# Intégrer Socket.IO dans Next.js API Routes
# (plus complexe mais architecture unifiée)
```

---

## 🎨 Design System avec shadcn/ui

### Composants shadcn à Installer

```bash
npx shadcn@latest init
npx shadcn@latest add button card dialog dropdown-menu
npx shadcn@latest add input label select slider switch
npx shadcn@latest add table tabs toast tooltip
npx shadcn@latest add accordion avatar badge separator
```

### Exemple Migration: MusicCard.vue → music-card.tsx

**Avant (Vue 3 - CSS vanilla):**
```vue
<template>
  <div class="music-card">
    <div class="music-info">
      <h3>{{ music.title }}</h3>
      <p>{{ music.artist }}</p>
    </div>
    <button @click="playMusic">Play</button>
  </div>
</template>

<style scoped>
.music-card {
  border: 1px solid #ccc;
  padding: 16px;
  border-radius: 8px;
}
</style>
```

**Après (React + Tailwind + shadcn):**
```tsx
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

export function MusicCard({ music }: { music: Music }) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <h3 className="font-semibold">{music.title}</h3>
        <p className="text-sm text-muted-foreground">{music.artist}</p>
      </CardHeader>
      <CardContent>
        <Button onClick={playMusic} size="sm">
          <Play className="mr-2 h-4 w-4" />
          Play
        </Button>
      </CardContent>
    </Card>
  )
}
```

### Avantages shadcn/ui

✅ **Composants accessibles** (ARIA, keyboard navigation)
✅ **Dark mode** intégré (via next-themes)
✅ **Variants** (CVA) - Boutons primary/secondary/ghost
✅ **Copy-paste** - Code source modifiable
✅ **Radix UI** - Primitives headless battle-tested

---

## 📋 Plan de Migration (5 Phases)

### Phase 1: Setup & Infra (1 semaine)
**Objectif:** Environnement Next.js opérationnel

- [ ] Initialiser Next.js 15 + TypeScript
- [ ] Configurer Tailwind CSS 4.0
- [ ] Installer shadcn/ui (composants de base)
- [ ] Setup Zustand stores
- [ ] Configurer ESLint + Prettier
- [ ] Dockeriser (dev + production)

**Livrable:** Page d'accueil fonctionnelle avec design system

---

### Phase 2: Backend API (1 semaine)
**Objectif:** Migrer backend Express ou intégrer dans Next.js

**Option A: Express Standalone**
- [ ] Copier backend Express existant
- [ ] Adapter CORS pour Next.js
- [ ] Tester Socket.IO avec Next.js client

**Option B: Next.js API Routes**
- [ ] Migrer routes REST vers app/api/
- [ ] Intégrer Socket.IO dans Next.js
- [ ] Setup tRPC (optionnel)

**Livrable:** API fonctionnelle + Socket.IO

---

### Phase 3: Bibliothèque Musicale (2 semaines)
**Objectif:** Migrer MusicLibrary + composants audio

**Composants à créer:**
- [ ] `music-card.tsx` (affichage piste)
- [ ] `music-filters.tsx` (filtres genre/mood/BPM)
- [ ] `audio-player.tsx` (lecteur avec contrôles)
- [ ] `waveform-player.tsx` (WaveSurfer.js wrapper)
- [ ] `music-library.tsx` (page principale)

**Store Zustand:**
```typescript
interface MusicStore {
  tracks: Track[]
  filters: MusicFilters
  currentTrack: Track | null
  isPlaying: boolean

  loadTracks: () => Promise<void>
  setFilters: (filters: MusicFilters) => void
  playTrack: (track: Track) => void
}
```

**API Routes:**
- `GET /api/music` - Liste pistes
- `GET /api/music/[id]` - Détails piste
- `POST /api/music/upload` - Upload
- `GET /api/music/[id]/download` - Stream audio

**Livrable:** Bibliothèque musicale complète

---

### Phase 4: Interface MC (2 semaines)
**Objectif:** Migrer MCInterface + MCLive

**Mode Préparation (`/mc/prep`):**
- [ ] `line-editor.tsx` - Édition feuille de match
- [ ] `match-template-selector.tsx` - Templates
- [ ] `personnel-assignment.tsx` - Assignation équipe
- [ ] `music-assignment-panel.tsx` - Drag & drop musiques

**Mode Live (`/mc/live`):**
- [ ] `match-timer.tsx` - Chronomètre
- [ ] `score-board.tsx` - Scores temps réel
- [ ] `live-controls.tsx` - Contrôles MC
- [ ] `sound-sync-indicator.tsx` - Indicateur sync Son

**Socket Events:**
```typescript
// MC → Sound
socket.emit('mc:timer-start', { matchId, lineId })
socket.emit('mc:next-line')
socket.emit('mc:score-update', { team, points })

// Sound → MC
socket.on('sound:music-playing', (trackId) => {})
socket.on('sound:ready', () => {})
```

**Livrable:** Interface MC complète (Prep + Live)

---

### Phase 5: Interface Son (2 semaines)
**Objectif:** Migrer SoundInterface + SoundLive

**Mode Préparation (`/sound/prep`):**
- [ ] `music-assignment.tsx` - Assignation musiques
- [ ] `music-preview.tsx` - Preview avec waveform
- [ ] `music-editor.tsx` - Trim/Fade/Volume

**Mode Live (`/sound/live`):**
- [ ] `live-player.tsx` - Lecteur principal
- [ ] `quick-search.tsx` - Recherche rapide bruitages
- [ ] `match-progress.tsx` - Vue progression match
- [ ] `mc-sync-view.tsx` - Vue synchronisée MC

**Store Zustand:**
```typescript
interface SoundStore {
  currentMatch: Match | null
  currentLine: Line | null
  assignedTracks: Map<string, Track>
  isPlaying: boolean

  assignTrack: (lineId: string, track: Track) => void
  playTrack: (trackId: string) => void
  syncWithMC: (data: MCState) => void
}
```

**Livrable:** Interface Son complète (Prep + Live)

---

### Phase 6: YouTube Downloader (1 semaine)
**Objectif:** Migrer YouTubeDownloader.vue

- [ ] `youtube-search.tsx` - Recherche vidéos
- [ ] `youtube-download.tsx` - Download + conversion
- [ ] `download-progress.tsx` - Progression temps réel
- [ ] Intégration Invidious (déjà dans code actuel)

**API Route:**
```typescript
// app/api/youtube/download/route.ts
POST /api/youtube/download
{
  url: string
  format: 'audio' | 'video'
  quality: 'high' | 'medium' | 'low'
}
```

**Livrable:** YouTube Downloader opérationnel

---

### Phase 7: Admin Panel (1 semaine)
**Objectif:** Créer admin panel (nouveau)

- [ ] `user-management.tsx` - Gestion utilisateurs
- [ ] `match-management.tsx` - Création matchs
- [ ] `music-moderation.tsx` - Modération bibliothèque
- [ ] `system-settings.tsx` - Configuration app

**Livrable:** Admin panel fonctionnel

---

## 🔄 Stratégie de Migration

### Approche Recommandée: **Réécriture Progressive**

**Étape 1:** Nouveau projet Next.js en parallèle
**Étape 2:** Migrer composant par composant
**Étape 3:** Tester chaque module isolément
**Étape 4:** Migration finale + switch DNS

### Timeline Estimée

| Phase | Durée | Effort (h) |
|-------|-------|-----------|
| Phase 1: Setup | 1 semaine | 20h |
| Phase 2: Backend | 1 semaine | 25h |
| Phase 3: Bibliothèque | 2 semaines | 50h |
| Phase 4: Interface MC | 2 semaines | 50h |
| Phase 5: Interface Son | 2 semaines | 50h |
| Phase 6: YouTube | 1 semaine | 20h |
| Phase 7: Admin | 1 semaine | 25h |
| **TOTAL** | **10 semaines** | **240h** |

---

## ⚖️ Analyse Coût/Bénéfice

### Avantages

✅ **Design System moderne** - UI cohérente
✅ **Accessibilité** - WCAG 2.1 AAA
✅ **Performance** - React Server Components
✅ **Maintenance** - Code TypeScript type-safe
✅ **Scalabilité** - Architecture modulaire
✅ **Dark Mode** - Intégré nativement
✅ **Mobile-first** - Tailwind responsive
✅ **Developer Experience** - Meilleur tooling

### Inconvénients

❌ **Temps de développement** - 10 semaines
❌ **Courbe d'apprentissage** - Next.js + React
❌ **Migration complexe** - Gros composants (38 KB)
❌ **Tests à réécrire** - Playwright à adapter
❌ **Risque régression** - Fonctionnalités existantes

### Coût (estimation freelance)

- **Développeur Senior React/Next.js** : 60-80€/h
- **240 heures** = **14,400€ - 19,200€**

### Alternatives

**Option 1: Améliorer Vue actuel**
- Ajouter Tailwind CSS à Vue
- Refactoriser composants monolithiques
- Coût: ~5,000€ (80h)

**Option 2: Hybrid (Vue + Tailwind + shadcn-vue)**
- shadcn-vue existe (port de shadcn pour Vue)
- Moins de migration, design system moderne
- Coût: ~8,000€ (130h)

---

## 🎯 Recommandation

### Recommandation Immédiate: **Option 2 - Hybrid Vue + Tailwind + shadcn-vue**

**Raisons:**
1. **Moins de risque** - Garde la base Vue existante
2. **Coût réduit** - 60% du coût de refacto complète
3. **Design system moderne** - shadcn-vue (officiel)
4. **Timeline courte** - 6-8 semaines au lieu de 10
5. **Réutilisation code** - Socket.IO, logique métier intacte

**Plan Hybrid:**
```bash
# 1. Installer Tailwind
npm install -D tailwindcss postcss autoprefixer

# 2. Installer shadcn-vue
npx shadcn-vue@latest init

# 3. Refactoriser composants progressivement
# Garde Vue 3 + Vite + Express backend
```

### Recommandation Long Terme: **Next.js Full**

Si l'application devient un produit SaaS multi-tenant avec :
- Authentification avancée (SSO, OAuth)
- SEO critique (pages publiques)
- Analytics embarqués
- API publique documentée

→ Alors refacto Next.js justifiée

---

## 📚 Ressources

**Next.js:**
- [Next.js 15 Docs](https://nextjs.org/docs)
- [App Router Guide](https://nextjs.org/docs/app)

**shadcn/ui:**
- [shadcn/ui Docs](https://ui.shadcn.com)
- [shadcn-vue](https://www.shadcn-vue.com) (port Vue)

**Tailwind:**
- [Tailwind CSS v4 Beta](https://tailwindcss.com/docs/v4-beta)

**Exemples:**
- [Next.js Music Player](https://github.com/shadcn/ui/tree/main/apps/www)
- [Next.js Dashboard Template](https://vercel.com/templates/next.js/admin-dashboard-tailwind-postgres-react-nextjs)

---

## ✅ Prochaines Étapes

Si décision de migration Next.js:

1. [ ] Créer nouveau repo `impro-manager-nextjs`
2. [ ] Setup projet Next.js 15 + Tailwind + shadcn
3. [ ] POC: Migrer 1 composant simple (MusicCard)
4. [ ] Valider approche avec équipe
5. [ ] Lancer Phase 1 (Setup)

Si décision Hybrid Vue:

1. [ ] Installer Tailwind dans projet actuel
2. [ ] Installer shadcn-vue
3. [ ] Migrer style.css → Tailwind utilities
4. [ ] Refactoriser SoundInterface.vue (38 KB) en sous-composants
5. [ ] Continuer migration progressive

---

**Document généré le 27 octobre 2025**
**Contact:** Équipe Dev Impro Manager
