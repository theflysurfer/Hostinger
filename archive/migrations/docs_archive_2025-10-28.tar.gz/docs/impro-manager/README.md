# 🎭 Impro Manager v2.0 - Documentation

Application de gestion de matchs d'improvisation théâtrale avec bibliothèque musicale intelligente.

## 📚 Documentation Disponible

- **[PRD.md](./PRD.md)** - Product Requirements Document complet
- **[ACTION_PLAN.md](./ACTION_PLAN.md)** - Plan technique détaillé en 10 sprints
- **[DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)** - Guide de déploiement sur Hostinger

## 🌐 Accès Production

**URL:** https://zimprobagnais.srv759970.hstgr.cloud  
**Credentials:** julien / DevAccess2025

**Endpoints API:**
- Health: `/api/health`
- Musiques: `/api/music`
- Matchs: `/api/matches`
- Personnel: `/api/personnel`

## 🏗️ Architecture

**Frontend:** Vue.js 3 + Vite  
**Backend:** Express.js + Socket.IO  
**Stockage:** JSON files + rclone mount OneDrive  
**Déploiement:** Docker + Nginx + HTTPS + Auto-start

## 📂 Repo GitHub

https://github.com/theflysurfer/Impro-manager

## 🎯 État Actuel

✅ **Phase 1:** Backend API + Frontend Interface MC Préparation  
✅ **Phase 2:** Bibliothèque Musicale (777+ pistes)  
🚧 **Phase 3:** Assignation Musicale (prochain)

## 🔄 Workflow Déploiement

```bash
# Local
git push origin master

# Serveur
ssh root@69.62.108.82
cd /opt/impro-manager
git pull origin master
docker-compose up -d --build
```

---

*Documentation générée le 2025-10-22*
