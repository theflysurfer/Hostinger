# Server Status - srv759970.hstgr.cloud

**Auto-généré** : Mis à jour automatiquement depuis le serveur.

---

## 💻 Informations Système

**Hostname**: `P24-JFERNANDEZ`
**IP**: 69.62.108.82
**OS**: 
**Kernel**: 3.6.4-b9f03e96.x86_64
**Uptime**: 

## 🧠 RAM

```
               total        used        free      shared  buff/cache   available
Mem:            15Gi       7.3Gi       554Mi        52Mi       8.3Gi       8.4Gi
Swap:             0B          0B          0B
```

## 💾 Disque

```
Filesystem          Size  Used Avail Use% Mounted on
tmpfs               1.6G  4.0M  1.6G   1% /run
/dev/sda1           193G  127G   67G  66% /
tmpfs               7.9G     0  7.9G   0% /dev/shm
tmpfs               5.0M     0  5.0M   0% /run/lock
/dev/sda16          881M  115M  705M  14% /boot
/dev/sda15          105M  6.1M   99M   6% /boot/efi
onedrive:Zic impro  1.1T  582G  458G  56% /opt/impro-manager/music
overlay             193G  127G   67G  66% /var/lib/docker/overlay2/02dcda8397c014af9ce8d66b01bfc4315ad7e8965ec746b1e45318deae5c2e74/merged
overlay             193G  127G   67G  66% /var/lib/docker/overlay2/dbb0d35968299333d3a21c18fcbcc4bf7ac407d818e2f17d1cf6e6e1d4f5e2e0/merged
```

## 📊 Load Average

```
 14:17:39 up 4 days, 22:13,  2 users,  load average: 1.10, 0.45, 0.40
```
