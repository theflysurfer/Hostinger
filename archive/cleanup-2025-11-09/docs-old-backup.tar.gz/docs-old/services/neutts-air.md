# NeuTTS-Air - Service de Synthèse Vocale avec Clonage de Voix

## Vue d'ensemble

NeuTTS-Air est un système de synthèse vocale (TTS) de haute qualité avec capacités de clonage de voix, déployé sur srv759970.hstgr.cloud. Le service inclut:

- **API FastAPI**: Backend de synthèse vocale avec support du streaming
- **Interface Streamlit**: Interface web intuitive pour tester le TTS
- **Support GPU/CPU**: Fonctionne en CPU par défaut, compatible GPU
- **Clonage de voix**: Clone n'importe quelle voix à partir de 3-15 secondes d'audio

## URLs d'Accès

- **Interface Streamlit**: https://neutts.srv759970.hstgr.cloud
- **API**: https://neutts-api.srv759970.hstgr.cloud
- **Documentation API**: https://neutts-api.srv759970.hstgr.cloud/docs

## Architecture

```
┌─────────────────┐
│  Internet       │
│  (HTTPS 443)    │
└────────┬────────┘
         │
    ┌────▼────┐
    │  Nginx  │
    └────┬────┘
         │
         ├────▶ neutts.srv759970.hstgr.cloud ──▶ Streamlit (8501)
         │                                              │
         │                                              ▼
         └────▶ neutts-api.srv759970.hstgr.cloud ──▶ FastAPI (8004)
                                                        │
                                                        ▼
                                                  NeuTTS-Air Model
                                                  (Hugging Face)
```

## Emplacement des Fichiers

```
/opt/neutts-air/
├── docker-compose.yml      # Configuration Docker
├── Dockerfile              # Image API
├── api.py                  # Serveur FastAPI
├── streamlit_app.py        # Interface Streamlit
├── samples/                # Audios de référence
├── outputs/                # Synthèses générées
├── nginx-neutts-air.conf   # Config Nginx
└── README.md               # Documentation
```

## Installation

L'installation est déjà complétée. Pour référence future:

```bash
# 1. Copier les fichiers
scp -r neutts-air-deploy/* root@srv759970.hstgr.cloud:/opt/neutts-air/

# 2. Démarrer les services
ssh root@srv759970.hstgr.cloud
cd /opt/neutts-air
docker-compose up -d

# 3. Configurer SSL
certbot certonly --nginx -d neutts-api.srv759970.hstgr.cloud
certbot certonly --nginx -d neutts.srv759970.hstgr.cloud

# 4. Activer Nginx
ln -sf /etc/nginx/sites-available/neutts-air /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

## Endpoints de l'API

### GET /
Informations générales sur l'API

```bash
curl https://neutts-api.srv759970.hstgr.cloud/
```

### GET /health
Vérification de l'état de l'API

```bash
curl https://neutts-api.srv759970.hstgr.cloud/health
# {"status": "healthy", "model_loaded": true}
```

### POST /synthesize
Synthèse vocale standard

```bash
curl -X POST https://neutts-api.srv759970.hstgr.cloud/synthesize \
  -F "text=Hello, this is a test of voice cloning" \
  -F "reference_audio=@reference.wav" \
  -F "reference_text=This is the reference transcript" \
  -o output.wav
```

### POST /stream
Synthèse vocale en streaming (temps réel)

```bash
curl -X POST https://neutts-api.srv759970.hstgr.cloud/stream \
  -F "text=Real-time streaming synthesis" \
  -F "reference_audio=@reference.wav" \
  -F "reference_text=Reference text" \
  -o streamed.wav
```

### POST /encode_reference
Pré-encoder un audio de référence pour réutilisation

```bash
curl -X POST https://neutts-api.srv759970.hstgr.cloud/encode_reference \
  -F "audio_file=@speaker.wav" \
  -F "reference_text=What the speaker says"
```

## Interface Streamlit

Accès: https://neutts.srv759970.hstgr.cloud

### Fonctionnalités

1. **Quick Synthesis**
   - Upload d'audio de référence (WAV, 3-15s)
   - Saisie de la transcription
   - Génération de synthèse vocale
   - Mode standard ou streaming

2. **Encode Reference**
   - Pré-encodage d'audios fréquents
   - Génération de codes réutilisables
   - Optimisation des performances

3. **Advanced Settings**
   - Configuration du modèle
   - Informations système
   - Documentation intégrée

## Gestion des Services

### Vérifier le statut

```bash
docker ps --filter name=neutts
# neutts-api        Up 10 minutes (healthy)
# neutts-streamlit  Up 10 minutes (healthy)
```

### Logs

```bash
# API
docker logs neutts-api -f

# Streamlit
docker logs neutts-streamlit -f

# Tous
cd /opt/neutts-air
docker-compose logs -f
```

### Redémarrer

```bash
cd /opt/neutts-air

# Un service
docker-compose restart neutts-api

# Tous
docker-compose restart
```

### Arrêter/Démarrer

```bash
cd /opt/neutts-air

# Arrêter
docker-compose down

# Démarrer
docker-compose up -d
```

## Audio de Référence - Bonnes Pratiques

Pour obtenir les meilleurs résultats de clonage:

### Format Audio
- **Type**: WAV mono
- **Sample Rate**: 16-44 kHz
- **Durée**: 3-15 secondes (optimal: 5-10s)
- **Qualité**: Audio propre, minimal de bruit

### Contenu
- Parole naturelle et continue
- Pas de musique ou effets sonores
- Éviter les silences longs
- Préférer un monologue à un dialogue

### Transcription
- Saisir exactement ce qui est dit
- Respecter la ponctuation
- Être précis pour meilleure qualité

## Performance

### Temps de Synthèse (CPU)

- **Première synthèse**: 30-60 secondes (download des modèles)
- **Synthèses suivantes**: 5-15 secondes pour 10s d'audio
- **Avec pré-encodage**: 3-10 secondes

### Optimisations Possibles

1. **GPU Support**: Modifier `backbone_device="cuda"` dans `api.py`
2. **GGUF Model**: Utiliser modèle quantifié pour latence réduite
3. **Pré-encodage**: Encoder les voix fréquemment utilisées
4. **ONNX Decoder**: Déjà inclus pour meilleures performances

## Monitoring

### Stats Docker

```bash
docker stats neutts-api neutts-streamlit
```

### Espace Disque

```bash
# Modèles Hugging Face
du -sh /var/lib/docker/volumes/neutts-air_neutts-models

# Outputs
du -sh /opt/neutts-air/outputs
```

### Logs Nginx

```bash
tail -f /var/log/nginx/neutts-api-access.log
tail -f /var/log/nginx/neutts-access.log
tail -f /var/log/nginx/neutts-api-error.log
```

## Troubleshooting

### API ne démarre pas

```bash
# Vérifier logs
docker logs neutts-api --tail 100

# Vérifier modèles
docker exec neutts-api ls -la /root/.cache/huggingface

# Reconstruire
cd /opt/neutts-air
docker-compose down
docker-compose build --no-cache neutts-api
docker-compose up -d
```

### Erreur de mémoire

```bash
# Vérifier RAM
free -h

# Ajouter swap si nécessaire
docker-compose down
docker-compose up -d
```

### Erreur 502 Nginx

```bash
# Vérifier que les services écoutent
netstat -tlnp | grep 8004
netstat -tlnp | grep 8501

# Logs Nginx
tail -50 /var/log/nginx/neutts-api-error.log
```

### Audio de mauvaise qualité

1. Vérifier qualité de l'audio de référence
2. S'assurer audio mono et 16-44kHz
3. Utiliser transcription précise
4. Tester différents échantillons

## Sécurité

### HTTPS

Certificats SSL automatiquement renouvelés par Certbot:

```bash
# Vérifier certificats
certbot certificates | grep neutts

# Test renouvellement
certbot renew --dry-run
```

### Limites de Ressources

Docker configuré avec:
- Restart automatique
- Health checks
- Rotation des logs (10MB max, 3 fichiers)

## Mise à Jour

```bash
cd /opt/neutts-air

# Pull nouvelles images
docker-compose pull

# Rebuild
docker-compose build --no-cache

# Redémarrer
docker-compose down
docker-compose up -d

# Vérifier
docker-compose logs -f
```

## Exemples d'Utilisation

### Python

```python
import requests

# Synthèse vocale
with open('reference.wav', 'rb') as ref:
    response = requests.post(
        'https://neutts-api.srv759970.hstgr.cloud/synthesize',
        files={'reference_audio': ref},
        data={
            'text': 'Text to synthesize with cloned voice',
            'reference_text': 'Reference transcript'
        }
    )

with open('output.wav', 'wb') as f:
    f.write(response.content)
```

### JavaScript/Node.js

```javascript
const FormData = require('form-data');
const fs = require('fs');

const form = new FormData();
form.append('reference_audio', fs.createReadStream('reference.wav'));
form.append('reference_text', 'Reference transcript');
form.append('text', 'Text to synthesize');

fetch('https://neutts-api.srv759970.hstgr.cloud/synthesize', {
    method: 'POST',
    body: form
})
.then(res => res.buffer())
.then(buffer => fs.writeFileSync('output.wav', buffer));
```

### Bash

```bash
#!/bin/bash

REF_AUDIO="speaker.wav"
REF_TEXT="This is what the speaker says"
TEXT="Clone this voice and say something new"

curl -X POST https://neutts-api.srv759970.hstgr.cloud/synthesize \
  -F "reference_audio=@${REF_AUDIO}" \
  -F "reference_text=${REF_TEXT}" \
  -F "text=${TEXT}" \
  -o synthesized.wav

echo "Audio saved to synthesized.wav"
```

## Ressources

- **Repository GitHub**: https://github.com/neuphonic/neutts-air
- **Documentation**: /opt/neutts-air/DEPLOYMENT_GUIDE.md
- **FastAPI Docs**: https://neutts-api.srv759970.hstgr.cloud/docs
- **Streamlit UI**: https://neutts.srv759970.hstgr.cloud

## Support

Pour des problèmes ou questions:

1. Vérifier les logs Docker
2. Consulter DEPLOYMENT_GUIDE.md
3. Tester l'accès local (localhost:8004, localhost:8501)
4. Vérifier Nginx et SSL
5. Consulter /var/log/nginx/

## Notes Techniques

- **Modèle**: neuphonic/neutts-air (PyTorch)
- **Codec**: neuphonic/neucodec
- **Sample Rate**: 24kHz
- **Device**: CPU (configurable GPU)
- **Watermark**: Perth (responsabilité)
- **Contexte**: 2048 tokens (~30s audio)
- **Langue**: English uniquement

## Date de Déploiement

- **Installation**: 21 octobre 2025
- **Statut**: ✅ Production
- **Version**: 1.0.0
