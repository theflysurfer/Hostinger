# Documentation srv759970.hstgr.cloud

Bienvenue sur la documentation technique complète du serveur **srv759970.hstgr.cloud**.

## 🚀 Services Principaux

### Stack Collaboration & Productivité

- **[Nextcloud](services/nextcloud.md)** - Stockage cloud et synchronisation de fichiers
- **[Rocket.Chat](services/rocketchat.md)** - Messagerie instantanée et collaboration d'équipe
- **[Jitsi Meet](services/jitsi.md)** - Visioconférence sécurisée et webinaires
- **[Bases de Données Partagées](services/databases-shared.md)** - MongoDB, PostgreSQL, Redis

### APIs de Transcription Audio

- **[WhisperX](services/whisperx.md)** - Transcription avancée avec diarization (qui parle quand)
- **[Faster-Whisper Queue](services/faster-whisper-queue.md)** - Transcription async avec gestion de queues RQ
- **[Monitoring WhisperX](services/monitoring.md)** - Stack Grafana + Prometheus + Loki

### Infrastructure & Outils

- **[Glances](services/glances.md)** - Monitoring système léger (métriques CPU, RAM, disque, Docker)
- **[Dozzle](services/dozzle.md)** - Visualisation logs Docker en temps réel
- **[Portainer](services/portainer.md)** - Interface de gestion Docker complète
- **[Monitoring Stack](services/monitoring.md)** - Prometheus + Grafana + Loki pour métriques et logs

### Autres Services

- **[Tika](services/tika.md)** - Parsing de documents (PDF, Office, images OCR)
- **[Ollama](services/ollama.md)** - Inférence LLM locale

## 🏗️ Infrastructure

- **[Docker](infrastructure/docker.md)** - Gestion des conteneurs et réseaux
- **[Nginx](infrastructure/nginx.md)** - Reverse proxy et configuration SSL
- **[Sécurité](infrastructure/security.md)** - Basic auth, SSL, firewall

## 📚 Guides

- **[Déploiement VPS](guides/deployment.md)** - Configuration initiale du serveur
- **[Email](guides/email.md)** - Configuration SMTP et alertes
- **[WordPress](guides/wordpress.md)** - Déploiement sites WordPress avec Docker

## 📊 Portails & Dashboards

### Collaboration
- **Nextcloud**: [https://nextcloud.srv759970.hstgr.cloud](https://nextcloud.srv759970.hstgr.cloud) - Stockage cloud
- **Rocket.Chat**: [https://chat.srv759970.hstgr.cloud](https://chat.srv759970.hstgr.cloud) - Messagerie
- **Jitsi Meet**: [https://meet.srv759970.hstgr.cloud](https://meet.srv759970.hstgr.cloud) - Visioconférence

### Monitoring & Infrastructure
- **Dashy Dashboard**: [https://dashy.srv759970.hstgr.cloud](https://dashy.srv759970.hstgr.cloud) - Vue d'ensemble services
- **Grafana Monitoring**: [https://monitoring.srv759970.hstgr.cloud](https://monitoring.srv759970.hstgr.cloud) - Métriques & Logs
- **Dozzle**: [https://dozzle.srv759970.hstgr.cloud](https://dozzle.srv759970.hstgr.cloud) - Logs Docker temps réel
- **Glances**: [https://glances.srv759970.hstgr.cloud](https://glances.srv759970.hstgr.cloud) - Monitoring système léger ✅ **Sécurisé**
- **Portainer**: [https://portainer.srv759970.hstgr.cloud](https://portainer.srv759970.hstgr.cloud) - Gestion Docker ✅ **Sécurisé**
- **RQ Dashboard**: [https://whisperx-dashboard.srv759970.hstgr.cloud](https://whisperx-dashboard.srv759970.hstgr.cloud) - Queues Redis

## 🔧 APIs Disponibles

| Service | URL | Documentation | Status |
|---------|-----|---------------|--------|
| WhisperX | https://whisperx.srv759970.hstgr.cloud | [Swagger](https://whisperx.srv759970.hstgr.cloud/docs) | ✅ |
| Faster-Whisper Queue | https://faster-whisper.srv759970.hstgr.cloud | [Swagger](https://faster-whisper.srv759970.hstgr.cloud/docs) | ✅ |
| Faster-Whisper (direct) | http://srv759970.hstgr.cloud:8001 | [Swagger](http://srv759970.hstgr.cloud:8001/docs) | ✅ |
| Tika | http://srv759970.hstgr.cloud:9998 | API REST | ✅ |
| Ollama | http://srv759970.hstgr.cloud:11434 | API REST | ✅ |

## 🏗️ Architecture

### Services de Transcription

```
┌──────────── Redis Partagé (rq-queue-redis:6379) ────────────┐
│                                                               │
│  DB 0: Queue "transcription" (WhisperX)                      │
│  DB 1: Queue "faster-whisper-transcription"                  │
│                                                               │
└───────────────────────────────────────────────────────────────┘
         ↓                                 ↓
   whisperx-worker              faster-whisper-worker
         ↓                                 ↓
   WhisperX API (:8002)         Faster-Whisper Queue API (:8003)
```

### Stack Monitoring

```
Grafana (:3001) → Prometheus (:9090) + Loki (:3100)
                       ↓                    ↓
                  RQ Exporters         Promtail
                       ↓                    ↓
                   Redis Queue         Docker Logs
```

## 🔗 Liens Rapides

- **Dashboards**:
  - [Dashy](https://dashy.srv759970.hstgr.cloud) - Vue d'ensemble des services
  - [Dozzle](https://dozzle.srv759970.hstgr.cloud) - Logs Docker temps réel
  - [Grafana](https://monitoring.srv759970.hstgr.cloud) - Métriques et logs

- **Monitoring**:
  - [Prometheus](http://srv759970.hstgr.cloud:9090) - Métriques time-series
  - [RQ Dashboard](https://whisperx-dashboard.srv759970.hstgr.cloud) - Queues Redis

## 📝 Dernières Mises à Jour

- **2025-10-21**: ✅ Glances déployé en remplacement de Netdata (incident serveur: Netdata incompatible avec 59 conteneurs)
- **2025-10-21**: ✅ Sécurisation CRITIQUE complétée - Portainer, Glances, Loki maintenant protégés (HTTPS + Basic Auth + localhost)
- **2025-10-21**: Documentation complète des outils d'infrastructure (Netdata, Dozzle, Portainer)
- **2025-10-21**: Identification et correction des problèmes de sécurité critiques
- **2025-10-21**: Déploiement stack collaboration complète (Nextcloud, Rocket.Chat, Jitsi Meet)
- **2025-10-21**: Infrastructure bases de données partagées (MongoDB, PostgreSQL, Redis)
- **2025-10-21**: Intégration ONLYOFFICE avec Nextcloud pour co-édition documents
- **2025-10-21**: Configuration auto-start/stop pour 22 services (optimisation RAM)
- **2025-10-21**: Configuration HTTPS pour Dozzle, WhisperX, Dashy
- **2025-10-20**: Ajout Faster-Whisper Queue API avec système RQ
- **2025-10-20**: Déploiement stack Grafana + Prometheus + Loki

---

*Documentation générée avec MkDocs Material - [https://docs.srv759970.hstgr.cloud](https://docs.srv759970.hstgr.cloud)*
